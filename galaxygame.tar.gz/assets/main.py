import pygame
import random
import math
import asyncio
import sys
import json
import platform

pygame.init()
pygame.font.init()

WIDTH, HEIGHT = 450, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Galaxy Striker: Fleet Edition")
clock = pygame.time.Clock()

BG_COLOR = (8, 8, 24)
WHITE = (255, 255, 255)
HEALTH_GREEN = (50, 220, 90)
HEALTH_RED = (200, 40, 40)
COIN_COLOR = (255, 215, 0)
AMMO_COLOR = (255, 170, 0)
HEAL_COLOR = (50, 255, 120)
BOMB_COLOR = (255, 80, 0)
DASH_COLOR = (0, 255, 180)
SHIELD_COLOR = (255, 200, 50)
ASTEROID_COLOR = (140, 140, 160)
BOSS_COLOR = (255, 30, 30)

font = pygame.font.Font(None, 24)
large_font = pygame.font.Font(None, 34)
small_font = pygame.font.Font(None, 18)

class Game:
    def __init__(self):
        self.player_w = 48
        self.player_h = 48
        self.player_x = float(WIDTH // 2 - self.player_w // 2)
        self.player_y = float(HEIGHT - self.player_h - 130)

        self.game_state = "AUTH_MENU"
        self.current_user = ""
        self.input_username = ""
        self.input_pin = ""
        self.active_input_field = "USER"
        self.auth_error_msg = ""
        self.auth_db = self.load_database()

        self.total_banked_orbs = 0
        self.armor_level = 1
        self.speed_level = 1
        self.damage_level = 1

        # 6 Unique Ship Models (Correctly Indexed & Balanced)
        self.skins = [
            {"name": "Viper Dart", "shape": "dart", "primary": (0, 220, 255), "sec": (255, 255, 255), "cost": 0, "unlocked": True},
            {"name": "Crimson Delta", "shape": "delta", "primary": (255, 50, 60), "sec": (255, 180, 0), "cost": 60, "unlocked": False},
            {"name": "Heavy Aegis", "shape": "heavy", "primary": (255, 200, 0), "sec": (255, 70, 0), "cost": 140, "unlocked": False},
            {"name": "Stealth X", "shape": "stealth", "primary": (170, 60, 255), "sec": (0, 255, 200), "cost": 220, "unlocked": False},
            {"name": "Twin-Fuselage", "shape": "twin", "primary": (50, 255, 140), "sec": (0, 200, 255), "cost": 320, "unlocked": False},
            {"name": "Cyber Dreadnought", "shape": "dread", "primary": (255, 0, 128), "sec": (0, 255, 255), "cost": 450, "unlocked": False}
        ]
        self.equipped_skin_idx = 0
        self.viewing_skin_idx = 0

        # Primary Weapons
        self.primary_weapons = [
            {"name": "PLASMA BLASTER", "cost": 0, "unlocked": True},
            {"name": "TRI-SCATTER", "cost": 80, "unlocked": False},
            {"name": "PULSE CANNON", "cost": 160, "unlocked": False},
            {"name": "FLAK CANNON", "cost": 250, "unlocked": False},
            {"name": "DEATH BEAM", "cost": 380, "unlocked": False}
        ]
        self.equipped_primary_idx = 0
        self.viewing_primary_idx = 0

        # Secondary Weapons
        self.secondary_weapons = [
            {"name": "NONE", "cost": 0, "unlocked": True},
            {"name": "PLASMA MINES", "cost": 75, "unlocked": False},
            {"name": "SEEKER MISSILES", "cost": 150, "unlocked": False},
            {"name": "TWIN AUTOGUNS", "cost": 280, "unlocked": False},
            {"name": "ORBITAL LASER", "cost": 420, "unlocked": False}
        ]
        self.equipped_sec_idx = 0
        self.viewing_sec_idx = 0

        self.reset_session()

        self.stars = [[random.randint(0, WIDTH), random.randint(0, HEIGHT), random.randint(140, 300)] for _ in range(45)]
        
        # In-game Controls
        self.fire_btn_rect = pygame.Rect(WIDTH - 85, HEIGHT - 105, 75, 75)
        self.bomb_btn_rect = pygame.Rect(WIDTH - 170, HEIGHT - 105, 75, 75)
        self.dash_btn_rect = pygame.Rect(WIDTH - 255, HEIGHT - 105, 75, 75)

        # Garage Menu Navigation
        self.skin_menu_btn = pygame.Rect(40, 115, 370, 38)
        self.primary_menu_btn = pygame.Rect(40, 160, 370, 38)
        self.sec_menu_btn = pygame.Rect(40, 205, 370, 38)
        self.armor_btn = pygame.Rect(40, 250, 370, 34)
        self.speed_btn = pygame.Rect(40, 290, 370, 34)
        self.damage_btn = pygame.Rect(40, 330, 370, 34)
        self.launch_btn_rect = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 110, 220, 50)
        self.logout_btn = pygame.Rect(WIDTH - 95, 22, 75, 26)

        # Shop Carousel Controls
        self.back_garage_btn = pygame.Rect(40, 30, 95, 34)
        self.shop_prev_btn = pygame.Rect(35, HEIGHT // 2 - 25, 50, 50)
        self.shop_next_btn = pygame.Rect(WIDTH - 85, HEIGHT // 2 - 25, 50, 50)
        self.shop_action_btn = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 135, 220, 48)

        # Auth Screen Buttons
        self.btn_auth_login = pygame.Rect(WIDTH // 2 - 130, HEIGHT // 2 - 30, 260, 55)
        self.btn_auth_signup = pygame.Rect(WIDTH // 2 - 130, HEIGHT // 2 + 45, 260, 55)
        self.input_user_rect = pygame.Rect(40, 200, 370, 48)
        self.input_pin_rect = pygame.Rect(40, 280, 370, 48)
        self.btn_submit_auth = pygame.Rect(WIDTH // 2 - 110, 360, 220, 50)
        self.btn_auth_back = pygame.Rect(40, 40, 95, 34)

        # Keypad for touch entry
        self.keypad_rects = []
        keys = ["1","2","3","4","5","6","7","8","9","0","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","CLR","DEL"]
        kw, kh = 38, 38
        start_x, start_y = 20, 440
        for i, k in enumerate(keys):
            r = i // 7
            c = i % 7
            w_box = kw if k not in ["CLR", "DEL"] else kw + 10
            self.keypad_rects.append((k, pygame.Rect(start_x + c * 58, start_y + r * 48, w_box, kh)))

        self.restart_btn_rect = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2 + 60, 240, 55)
        self.active_touches = {}

    def load_database(self):
        try:
            if hasattr(platform, "window"):
                raw = platform.window.localStorage.getItem("galaxy_pilot_db")
                if raw:
                    return json.loads(str(raw))
        except Exception:
            pass
        return {}

    def save_database(self):
        try:
            if hasattr(platform, "window"):
                raw_str = json.dumps(self.auth_db)
                platform.window.localStorage.setItem("galaxy_pilot_db", raw_str)
        except Exception:
            pass

    def load_user_profile(self, username):
        profile = self.auth_db.get(username, {}).get("profile", {})
        self.total_banked_orbs = profile.get("orbs", 0)
        self.armor_level = profile.get("armor", 1)
        self.speed_level = profile.get("speed", 1)
        self.damage_level = profile.get("damage", 1)
        self.equipped_skin_idx = profile.get("skin_idx", 0)
        self.equipped_primary_idx = profile.get("pri_idx", 0)
        self.equipped_sec_idx = profile.get("sec_idx", 0)

        unlocked_skins = profile.get("unlocked_skins", [0])
        for i, s in enumerate(self.skins):
            s["unlocked"] = (i in unlocked_skins or i == 0)

        unlocked_pris = profile.get("unlocked_pris", [0])
        for i, pw in enumerate(self.primary_weapons):
            pw["unlocked"] = (i in unlocked_pris or i == 0)

        unlocked_secs = profile.get("unlocked_secs", [0])
        for i, sw in enumerate(self.secondary_weapons):
            sw["unlocked"] = (i in unlocked_secs or i == 0)

    def save_current_user_profile(self):
        if not self.current_user or self.current_user not in self.auth_db:
            return
        
        unlocked_skins = [i for i, s in enumerate(self.skins) if s["unlocked"]]
        unlocked_pris = [i for i, pw in enumerate(self.primary_weapons) if pw["unlocked"]]
        unlocked_secs = [i for i, sw in enumerate(self.secondary_weapons) if sw["unlocked"]]
        self.auth_db[self.current_user]["profile"] = {
            "orbs": self.total_banked_orbs,
            "armor": self.armor_level,
            "speed": self.speed_level,
            "damage": self.damage_level,
            "skin_idx": self.equipped_skin_idx,
            "pri_idx": self.equipped_primary_idx,
            "sec_idx": self.equipped_sec_idx,
            "unlocked_skins": unlocked_skins,
            "unlocked_pris": unlocked_pris,
            "unlocked_secs": unlocked_secs
        }
        self.save_database()

    def reset_session(self):
        self.max_hp = 3 + self.armor_level
        self.hp = self.max_hp
        self.player_x = float(WIDTH // 2 - self.player_w // 2)
        self.bombs = 1
        self.dash_charges = 2

        self.primary_ammo = 80
        self.secondary_ammo = 30

        self.heat = 0.0
        self.max_heat = 100.0
        self.is_overheated = False
        self.overheat_cooldown = 0.0
        self.fire_cooldown = 0.0
        self.sec_fire_timer = 0.0

        # 10 Dynamic In-Game Powers & Timers
        self.timer_triple_shot = 0.0
        self.timer_rapid_fire = 0.0
        self.timer_shield = 0.0
        self.timer_time_slow = 0.0
        self.timer_magnet = 0.0
        self.timer_piercing = 0.0
        self.timer_infinite_ammo = 0.0
        self.timer_overdrive = 0.0
        self.timer_cryo_freeze = 0.0
        self.dash_timer = 0.0

        self.lasers = []
        self.missiles = []
        self.mines = []
        self.enemy_lasers = []
        self.enemies = []
        self.asteroids = []
        self.coins = []
        self.heals = []
        self.ammo_crates = []
        self.power_orbs = []
        self.particles = []
        self.floating_texts = []
        self.boss = None

        self.score = 0
        self.current_level = 1
        self.coins_collected = 0
        self.enemy_timer = 0.0
        self.asteroid_timer = 0.0
        self.coin_timer = 0.0
        self.heal_timer = 0.0
        self.ammo_timer = 0.0
        self.power_timer = 0.0

    def spawn_particles(self, x, y, color, count=6):
        for _ in range(count):
            self.particles.append([x, y, random.uniform(-180, 180), random.uniform(-180, 180), random.uniform(0.2, 0.45), color])

    def add_floating_text(self, text, x, y, color):
        self.floating_texts.append([text, x, y, 0.6, color])

    def trigger_nuke(self):
        if self.bombs > 0:
            self.bombs -= 1
            self.add_floating_text("MEGA NUKE!", WIDTH // 2 - 60, HEIGHT // 2, BOMB_COLOR)
            for e in self.enemies:
                self.spawn_particles(e[0] + e[2]//2, e[1] + e[2]//2, e[5], 8)
                self.score += 1
            self.enemies.clear()
            self.asteroids.clear()
            self.enemy_lasers.clear()
            if self.boss:
                self.boss["hp"] -= 25

    def trigger_dash(self):
        if self.dash_charges > 0:
            self.dash_charges -= 1
            self.dash_timer = 0.4
            self.add_floating_text("WARP DASH!", WIDTH // 2 - 50, HEIGHT // 2, DASH_COLOR)

    def draw_custom_ship(self, surface, x, y, skin, scale=1.0):
        shape = skin["shape"]
        p_col = skin["primary"]
        s_col = skin["sec"]
        
        if shape == "dart":
            points = [(x, y - 22*scale), (x - 18*scale, y + 18*scale), (x - 6*scale, y + 10*scale), (x, y + 15*scale), (x + 6*scale, y + 10*scale), (x + 18*scale, y + 18*scale)]
            pygame.draw.polygon(surface, p_col, points)
            pygame.draw.polygon(surface, s_col, [(x, y - 10*scale), (x - 5*scale, y + 8*scale), (x + 5*scale, y + 8*scale)])
            pygame.draw.line(surface, s_col, (x - 18*scale, y + 6*scale), (x - 18*scale, y + 18*scale), max(1, int(3*scale)))
            pygame.draw.line(surface, s_col, (x + 18*scale, y + 6*scale), (x + 18*scale, y + 18*scale), max(1, int(3*scale)))

        elif shape == "delta":
            points = [(x, y - 24*scale), (x - 24*scale, y + 16*scale), (x, y + 8*scale), (x + 24*scale, y + 16*scale)]
            pygame.draw.polygon(surface, p_col, points)
            pygame.draw.polygon(surface, s_col, [(x, y - 24*scale), (x - 8*scale, y + 12*scale), (x + 8*scale, y + 12*scale)])
            pygame.draw.rect(surface, (255, 255, 255), (x - 18*scale, y + 4*scale, 4*scale, 14*scale), border_radius=2)
            pygame.draw.rect(surface, (255, 255, 255), (x + 14*scale, y + 4*scale, 4*scale, 14*scale), border_radius=2)

        elif shape == "heavy":
            points = [(x - 10*scale, y - 22*scale), (x + 10*scale, y - 22*scale), (x + 22*scale, y - 2*scale), (x + 18*scale, y + 20*scale), (x - 18*scale, y + 20*scale), (x - 22*scale, y - 2*scale)]
            pygame.draw.polygon(surface, p_col, points)
            pygame.draw.rect(surface, s_col, (x - 12*scale, y - 10*scale, 24*scale, 24*scale), border_radius=3)
            pygame.draw.circle(surface, (255, 255, 255), (int(x), int(y + 2*scale)), max(2, int(5*scale)))

        elif shape == "stealth":
            points = [(x, y - 24*scale), (x - 6*scale, y - 4*scale), (x - 26*scale, y - 16*scale), (x - 16*scale, y + 18*scale), (x, y + 6*scale), (x + 16*scale, y + 18*scale), (x + 26*scale, y - 16*scale), (x + 6*scale, y - 4*scale)]
            pygame.draw.polygon(surface, p_col, points)
            pygame.draw.line(surface, s_col, (x, y - 20*scale), (x, y + 6*scale), max(1, int(3*scale)))

        elif shape == "twin":
            pygame.draw.rect(surface, p_col, (x - 22*scale, y - 18*scale, 12*scale, 36*scale), border_radius=4)
            pygame.draw.rect(surface, p_col, (x + 10*scale, y - 18*scale, 12*scale, 36*scale), border_radius=4)
            pygame.draw.rect(surface, s_col, (x - 10*scale, y - 6*scale, 20*scale, 16*scale), border_radius=3)
            pygame.draw.polygon(surface, (255, 255, 255), [(x, y - 14*scale), (x - 5*scale, y - 2*scale), (x + 5*scale, y - 2*scale)])

        elif shape == "dread":
            points = [(x, y - 26*scale), (x - 28*scale, y + 8*scale), (x - 20*scale, y + 20*scale), (x - 8*scale, y + 10*scale), (x + 8*scale, y + 10*scale), (x + 20*scale, y + 20*scale), (x + 28*scale, y + 8*scale)]
            pygame.draw.polygon(surface, p_col, points)
            pygame.draw.polygon(surface, s_col, [(x, y - 16*scale), (x - 12*scale, y + 4*scale), (x, y + 12*scale), (x + 12*scale, y + 4*scale)])
            pygame.draw.circle(surface, (255, 255, 255), (int(x), int(y - 2*scale)), max(2, int(4*scale)))

async def main():
    g = Game()
    last_time = pygame.time.get_ticks()

    running = True
    while running:
        current_time = pygame.time.get_ticks()
        dt = (current_time - last_time) / 1000.0
        last_time = current_time
        dt = min(dt, 0.05)
        physics_dt = dt * 0.4 if g.timer_time_slow > 0 else dt

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            elif event.type == pygame.KEYDOWN and g.game_state in ["LOGIN_SCREEN", "SIGNUP_SCREEN"]:
                if event.key == pygame.K_BACKSPACE:
                    if g.active_input_field == "USER": g.input_username = g.input_username[:-1]
                    else: g.input_pin = g.input_pin[:-1]
                elif event.key == pygame.K_TAB:
                    g.active_input_field = "PIN" if g.active_input_field == "USER" else "USER"
                elif event.unicode.isalnum() and len(event.unicode) == 1:
                    if g.active_input_field == "USER" and len(g.input_username) < 10:
                        g.input_username += event.unicode.upper()
                    elif g.active_input_field == "PIN" and len(g.input_pin) < 4 and event.unicode.isdigit():
                        g.input_pin += event.unicode

            elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                if event.type == pygame.FINGERDOWN:
                    pos = (int(event.x * WIDTH), int(event.y * HEIGHT))
                    tid = event.finger_id
                else:
                    pos = pygame.mouse.get_pos()
                    tid = 'mouse'

                g.active_touches[tid] = pos

                # AUTH MENU
                if g.game_state == "AUTH_MENU":
                    if g.btn_auth_login.collidepoint(pos):
                        g.input_username = ""
                        g.input_pin = ""
                        g.auth_error_msg = ""
                        g.game_state = "LOGIN_SCREEN"
                    elif g.btn_auth_signup.collidepoint(pos):
                        g.input_username = ""
                        g.input_pin = ""
                        g.auth_error_msg = ""
                        g.game_state = "SIGNUP_SCREEN"

                # LOGIN OR SIGNUP SCREEN
                elif g.game_state in ["LOGIN_SCREEN", "SIGNUP_SCREEN"]:
                    if g.btn_auth_back.collidepoint(pos):
                        g.game_state = "AUTH_MENU"
                    elif g.input_user_rect.collidepoint(pos):
                        g.active_input_field = "USER"
                    elif g.input_pin_rect.collidepoint(pos):
                        g.active_input_field = "PIN"
                    
                    for key_char, k_rect in g.keypad_rects:
                        if k_rect.collidepoint(pos):
                            if key_char == "DEL":
                                if g.active_input_field == "USER": g.input_username = g.input_username[:-1]
                                else: g.input_pin = g.input_pin[:-1]
                            elif key_char == "CLR":
                                if g.active_input_field == "USER": g.input_username = ""
                                else: g.input_pin = ""
                            else:
                                if g.active_input_field == "USER" and len(g.input_username) < 10:
                                    g.input_username += key_char
                                elif g.active_input_field == "PIN" and len(g.input_pin) < 4 and key_char.isdigit():
                                    g.input_pin += key_char

                    if g.btn_submit_auth.collidepoint(pos):
                        user = g.input_username.strip()
                        pin = g.input_pin.strip()
                        if len(user) < 2 or len(pin) < 4:
                            g.auth_error_msg = "User 2+ chars, PIN 4 digits!"
                        elif g.game_state == "SIGNUP_SCREEN":
                            if user in g.auth_db:
                                g.auth_error_msg = "Callsign already exists!"
                            else:
                                g.auth_db[user] = {"pin": pin, "profile": {}}
                                g.current_user = user
                                g.load_user_profile(user)
                                g.save_current_user_profile()
                                g.game_state = "GARAGE"
                        elif g.game_state == "LOGIN_SCREEN":
                            if user not in g.auth_db or g.auth_db[user].get("pin") != pin:
                                g.auth_error_msg = "Invalid Callsign or PIN!"
                            else:
                                g.current_user = user
                                g.load_user_profile(user)
                                g.game_state = "GARAGE"

                # GARAGE SCREEN
                elif g.game_state == "GARAGE":
                    if g.logout_btn.collidepoint(pos):
                        g.save_current_user_profile()
                        g.current_user = ""
                        g.game_state = "AUTH_MENU"
                    elif g.skin_menu_btn.collidepoint(pos):
                        g.viewing_skin_idx = g.equipped_skin_idx
                        g.game_state = "SKIN_SHOP"
                    elif g.primary_menu_btn.collidepoint(pos):
                        g.viewing_primary_idx = g.equipped_primary_idx
                        g.game_state = "PRI_SHOP"
                    elif g.sec_menu_btn.collidepoint(pos):
                        g.viewing_sec_idx = g.equipped_sec_idx
                        g.game_state = "SEC_SHOP"
                    elif g.armor_btn.collidepoint(pos) and g.total_banked_orbs >= 25:
                        g.total_banked_orbs -= 25
                        g.armor_level += 1
                        g.save_current_user_profile()
                    elif g.speed_btn.collidepoint(pos) and g.total_banked_orbs >= 25:
                        g.total_banked_orbs -= 25
                        g.speed_level += 1
                        g.save_current_user_profile()
                    elif g.damage_btn.collidepoint(pos) and g.total_banked_orbs >= 25:
                        g.total_banked_orbs -= 25
                        g.damage_level += 1
                        g.save_current_user_profile()
                    elif g.launch_btn_rect.collidepoint(pos):
                        g.reset_session()
                        g.active_touches.clear()
                        last_time = pygame.time.get_ticks()
                        g.game_state = "PLAYING"

                # SKIN SHOP
                elif g.game_state == "SKIN_SHOP":
                    if g.back_garage_btn.collidepoint(pos):
                        g.save_current_user_profile()
                        g.game_state = "GARAGE"
                    elif g.shop_prev_btn.collidepoint(pos):
                        g.viewing_skin_idx = (g.viewing_skin_idx - 1) % len(g.skins)
                    elif g.shop_next_btn.collidepoint(pos):
                        g.viewing_skin_idx = (g.viewing_skin_idx + 1) % len(g.skins)
                    elif g.shop_action_btn.collidepoint(pos):
                        sk = g.skins[g.viewing_skin_idx]
                        if not sk["unlocked"] and g.total_banked_orbs >= sk["cost"]:
                            g.total_banked_orbs -= sk["cost"]
                            sk["unlocked"] = True
                            g.equipped_skin_idx = g.viewing_skin_idx
                            g.save_current_user_profile()
                        elif sk["unlocked"]:
                            g.equipped_skin_idx = g.viewing_skin_idx
                            g.save_current_user_profile()

                # PRIMARY WEAPON SHOP
                elif g.game_state == "PRI_SHOP":
                    if g.back_garage_btn.collidepoint(pos):
                        g.save_current_user_profile()
                        g.game_state = "GARAGE"
                    elif g.shop_prev_btn.collidepoint(pos):
                        g.viewing_primary_idx = (g.viewing_primary_idx - 1) % len(g.primary_weapons)
                    elif g.shop_next_btn.collidepoint(pos):
                        g.viewing_primary_idx = (g.viewing_primary_idx + 1) % len(g.primary_weapons)
                    elif g.shop_action_btn.collidepoint(pos):
                        pw = g.primary_weapons[g.viewing_primary_idx]
                        if not pw["unlocked"] and g.total_banked_orbs >= pw["cost"]:
                            g.total_banked_orbs -= pw["cost"]
                            pw["unlocked"] = True
                            g.equipped_primary_idx = g.viewing_primary_idx
                            g.save_current_user_profile()
                        elif pw["unlocked"]:
                            g.equipped_primary_idx = g.viewing_primary_idx
                            g.save_current_user_profile()

                # SECONDARY WEAPON SHOP
                elif g.game_state == "SEC_SHOP":
                    if g.back_garage_btn.collidepoint(pos):
                        g.save_current_user_profile()
                        g.game_state = "GARAGE"
                    elif g.shop_prev_btn.collidepoint(pos):
                        g.viewing_sec_idx = (g.viewing_sec_idx - 1) % len(g.secondary_weapons)
                    elif g.shop_next_btn.collidepoint(pos):
                        g.viewing_sec_idx = (g.viewing_sec_idx + 1) % len(g.secondary_weapons)
                    elif g.shop_action_btn.collidepoint(pos):
                        sw = g.secondary_weapons[g.viewing_sec_idx]
                        if not sw["unlocked"] and g.total_banked_orbs >= sw["cost"]:
                            g.total_banked_orbs -= sw["cost"]
                            sw["unlocked"] = True
                            g.equipped_sec_idx = g.viewing_sec_idx
                            g.save_current_user_profile()
                        elif sw["unlocked"]:
                            g.equipped_sec_idx = g.viewing_sec_idx
                            g.save_current_user_profile()

                elif g.game_state == "GAMEOVER":
                    if g.restart_btn_rect.collidepoint(pos):
                        g.total_banked_orbs += g.coins_collected
                        g.save_current_user_profile()
                        g.game_state = "GARAGE"

                elif g.game_state == "PLAYING":
                    if g.bomb_btn_rect.collidepoint(pos):
                        g.trigger_nuke()
                    elif g.dash_btn_rect.collidepoint(pos):
                        g.trigger_dash()

            elif event.type == pygame.FINGERMOTION:
                g.active_touches[event.finger_id] = (int(event.x * WIDTH), int(event.y * HEIGHT))
            elif event.type == pygame.MOUSEMOTION:
                if 'mouse' in g.active_touches:
                    g.active_touches['mouse'] = pygame.mouse.get_pos()
            elif event.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP):
                tid = event.finger_id if event.type == pygame.FINGERUP else 'mouse'
                if tid in g.active_touches:
                    del g.active_touches[tid]

        if g.game_state == "PLAYING":
            g.current_level = max(1, 1 + g.score // 25)
            diff_factor = 1.0 + (g.current_level * 0.22)

            is_touching_fire = False
            is_moving = False
            move_target_x = g.player_x

            for tid, pos in g.active_touches.items():
                if g.fire_btn_rect.collidepoint(pos):
                    is_touching_fire = True
                elif g.bomb_btn_rect.collidepoint(pos) or g.dash_btn_rect.collidepoint(pos):
                    pass
                else:
                    is_moving = True
                    move_target_x = pos[0] - g.player_w // 2

            if is_moving:
                base_spd = 26.0 + (g.speed_level * 4.0)
                current_speed = base_spd * (2.2 if g.dash_timer > 0 else 1.0)
                player_target_x = move_target_x - g.player_x
                g.player_x += player_target_x * min(1.0, current_speed * dt)
                g.player_x = max(0.0, min(float(WIDTH - g.player_w), g.player_x))

            if g.is_overheated:
                g.overheat_cooldown -= dt
                g.heat = (g.overheat_cooldown / 1.2) * 100.0
                if g.overheat_cooldown <= 0:
                    g.is_overheated = False
                    g.heat = 0.0
            else:
                if not is_touching_fire and g.heat > 0:
                    g.heat = max(0.0, g.heat - 50.0 * dt)

            base_cd = 0.07 if g.timer_rapid_fire > 0 else 0.13
            if g.fire_cooldown > 0:
                g.fire_cooldown -= dt

            if is_touching_fire and not g.is_overheated and g.fire_cooldown <= 0:
                if g.primary_ammo > 0 or g.timer_infinite_ammo > 0:
                    cx = g.player_x + g.player_w // 2
                    cy = g.player_y
                    dmg = g.damage_level
                    p_name = g.primary_weapons[g.equipped_primary_idx]["name"]

                    if g.timer_overdrive > 0:
                        g.lasers.append([cx - 18, cy, -80, -1300, (255, 0, 255), dmg + 1, 8, 20, False])
                        g.lasers.append([cx - 6, cy, 0, -1400, (255, 0, 255), dmg + 1, 8, 24, False])
                        g.lasers.append([cx + 6, cy, 0, -1400, (255, 0, 255), dmg + 1, 8, 24, False])
                        g.lasers.append([cx + 18, cy, 80, -1300, (255, 0, 255), dmg + 1, 8, 20, False])
                    elif g.timer_triple_shot > 0:
                        g.lasers.append([cx, cy, -130, -1150, (0, 255, 180), dmg, 6, 16, g.timer_piercing > 0])
                        g.lasers.append([cx, cy, 0, -1200, (0, 255, 180), dmg, 6, 16, g.timer_piercing > 0])
                        g.lasers.append([cx, cy, 130, -1150, (0, 255, 180), dmg, 6, 16, g.timer_piercing > 0])
                    else:
                        if p_name == "PLASMA BLASTER":
                            g.lasers.append([cx - 8, cy, 0, -1200, (0, 220, 255), dmg, 6, 16, g.timer_piercing > 0])
                            g.lasers.append([cx + 8, cy, 0, -1200, (0, 220, 255), dmg, 6, 16, g.timer_piercing > 0])
                        elif p_name == "TRI-SCATTER":
                            g.lasers.append([cx, cy, -140, -1100, (200, 50, 255), dmg, 6, 14, g.timer_piercing > 0])
                            g.lasers.append([cx, cy, 0, -1100, (200, 50, 255), dmg, 6, 14, g.timer_piercing > 0])
                            g.lasers.append([cx, cy, 140, -1100, (200, 50, 255), dmg, 6, 14, g.timer_piercing > 0])
                        elif p_name == "PULSE CANNON":
                            g.lasers.append([cx, cy, 0, -1450, (255, 60, 100), dmg + 1, 8, 24, g.timer_piercing > 0])
                        elif p_name == "FLAK CANNON":
                            for _ in range(4):
                                g.lasers.append([cx, cy, random.uniform(-160, 160), random.uniform(-900, -1200), (255, 200, 50), dmg, 6, 8, False])
                        elif p_name == "DEATH BEAM":
                            g.lasers.append([cx - 4, cy - 20, 0, -1800, (0, 255, 200), dmg + 2, 8, 36, True])

                    if g.timer_infinite_ammo <= 0:
                        g.primary_ammo -= 1

                    g.fire_cooldown = base_cd
                    g.heat += 3.8
                    if g.heat >= g.max_heat:
                        g.heat = 100.0
                        g.is_overheated = True
                        g.overheat_cooldown = 1.2
                        g.add_floating_text("OVERHEATED!", g.player_x - 15, g.player_y - 25, HEALTH_RED)
                else:
                    g.add_floating_text("NO AMMO!", g.player_x - 10, g.player_y - 25, AMMO_COLOR)
                    g.fire_cooldown = 0.4

            g.sec_fire_timer += dt
            s_name = g.secondary_weapons[g.equipped_sec_idx]["name"]
            cx = g.player_x + g.player_w // 2
            cy = g.player_y

            if s_name != "NONE" and (g.secondary_ammo > 0 or g.timer_infinite_ammo > 0):
                if s_name == "PLASMA MINES" and g.sec_fire_timer > 1.8:
                    g.mines.append([cx, cy - 10, 0.0])
                    if g.timer_infinite_ammo <= 0: g.secondary_ammo -= 1
                    g.sec_fire_timer = 0.0
                elif s_name == "SEEKER MISSILES" and g.sec_fire_timer > 0.9:
                    g.missiles.append([cx - 20, cy, random.uniform(-60, -20), -420])
                    g.missiles.append([cx + 20, cy, random.uniform(20, 60), -420])
                    if g.timer_infinite_ammo <= 0: g.secondary_ammo -= 2
                    g.sec_fire_timer = 0.0
                elif s_name == "TWIN AUTOGUNS" and g.sec_fire_timer > 0.22:
                    g.lasers.append([cx - 24, cy + 10, -40, -1000, (255, 255, 100), 1, 4, 12, False])
                    g.lasers.append([cx + 24, cy + 10, 40, -1000, (255, 255, 100), 1, 4, 12, False])
                    if g.timer_infinite_ammo <= 0: g.secondary_ammo -= 1
                    g.sec_fire_timer = 0.0
                elif s_name == "ORBITAL LASER" and g.sec_fire_timer > 1.2:
                    g.lasers.append([cx - 35, cy - 40, 0, -1600, (255, 0, 200), 4, 10, 36, True])
                    g.lasers.append([cx + 35, cy - 40, 0, -1600, (255, 0, 200), 4, 10, 36, True])
                    if g.timer_infinite_ammo <= 0: g.secondary_ammo -= 2
                    g.sec_fire_timer = 0.0

            if g.timer_triple_shot > 0: g.timer_triple_shot -= dt
            if g.timer_rapid_fire > 0: g.timer_rapid_fire -= dt
            if g.timer_shield > 0: g.timer_shield -= dt
            if g.timer_time_slow > 0: g.timer_time_slow -= dt
            if g.timer_magnet > 0: g.timer_magnet -= dt
            if g.timer_piercing > 0: g.timer_piercing -= dt
            if g.timer_infinite_ammo > 0: g.timer_infinite_ammo -= dt
            if g.timer_overdrive > 0: g.timer_overdrive -= dt
            if g.timer_cryo_freeze > 0: g.timer_cryo_freeze -= dt
            if g.dash_timer > 0: g.dash_timer -= dt

            g.enemy_timer += physics_dt
            spawn_rate = max(0.24, 0.65 / diff_factor)
            if g.enemy_timer > spawn_rate and g.boss is None:
                is_elite = random.random() < min(0.45, 0.18 * diff_factor)
                spd = (230.0 + (diff_factor * 30.0))
                if is_elite:
                    g.enemies.append([random.randint(20, WIDTH - 70), -50, 48, spd * 0.75, 0.45 / diff_factor, (200, 50, 255), int(3 + diff_factor), True])
                else:
                    g.enemies.append([random.randint(20, WIDTH - 60), -40, 34, spd, 0.65 / diff_factor, (255, 60, 90), 1, False])
                g.enemy_timer = 0.0

            g.asteroid_timer += physics_dt
            if g.asteroid_timer > max(1.4, 2.8 / diff_factor) and g.boss is None:
                g.asteroids.append([random.randint(30, WIDTH - 50), -40, random.randint(22, 34), 180.0 * diff_factor, 2])
                g.asteroid_timer = 0.0

            g.coin_timer += physics_dt
            if g.coin_timer > 0.8:
                g.coins.append([random.randint(20, WIDTH - 40), -20, 9, 240.0])
                g.coin_timer = 0.0

            g.power_timer += physics_dt
            if g.power_timer > 5.5:
                pow_type = random.choice(["TRIPLE", "RAPID", "SHIELD", "TIME_SLOW", "MAGNET", "PIERCE", "INF_AMMO", "OVERDRIVE", "CRYO", "NUKE_PACK"])
                g.power_orbs.append([random.randint(30, WIDTH - 50), -20, pow_type, 210.0])
                g.power_timer = 0.0

            # Reduced Ammo Drop Rate: spawns every 10s and elite drop chance reduced to 25%
            g.ammo_timer += physics_dt
            if g.ammo_timer > 10.0:
                g.ammo_crates.append([random.randint(30, WIDTH - 50), -20, 210.0])
                g.ammo_timer = 0.0

            g.heal_timer += physics_dt
            if g.heal_timer > 16.0:
                g.heals.append([random.randint(30, WIDTH - 50), -20, 200.0])
                g.heal_timer = 0.0

            if g.score >= 30 and g.score % 30 == 0 and g.boss is None:
                g.boss = {"x": WIDTH // 2 - 60, "y": 70, "w": 120, "h": 50, "hp": int(30 * diff_factor), "max_hp": int(30 * diff_factor), "dir": 1, "speed": 180 * min(1.6, diff_factor), "shoot": 0.0}

            for l in g.lasers[:]:
                l[0] += l[2] * dt
                l[1] += l[3] * dt
                if l[1] < -40 or l[0] < 0 or l[0] > WIDTH:
                    g.lasers.remove(l)

            for m in g.missiles[:]:
                target = None
                if g.boss:
                    target = (g.boss["x"] + g.boss["w"] // 2, g.boss["y"] + g.boss["h"] // 2)
                elif g.enemies:
                    closest = min(g.enemies, key=lambda e: math.hypot(e[0] - m[0], e[1] - m[1]))
                    target = (closest[0] + closest[2] // 2, closest[1] + closest[2] // 2)

                if target:
                    dx, dy = target[0] - m[0], target[1] - m[1]
                    dist = math.hypot(dx, dy)
                    if dist > 0:
                        m[2] += (dx / dist) * 900.0 * dt
                        m[3] += (dy / dist) * 900.0 * dt
                m[0] += m[2] * dt
                m[1] += m[3] * dt
                if m[1] < -20 or m[1] > HEIGHT + 20:
                    g.missiles.remove(m)

            for mine in g.mines[:]:
                mine[2] += dt
                if mine[2] > 4.0:
                    g.mines.remove(mine)

            for el in g.enemy_lasers[:]:
                el[1] += el[2] * physics_dt
                if el[1] > HEIGHT:
                    g.enemy_lasers.remove(el)

            player_rect = pygame.Rect(int(g.player_x), int(g.player_y), g.player_w, g.player_h)

            if g.boss:
                if g.timer_cryo_freeze <= 0:
                    g.boss["x"] += g.boss["speed"] * g.boss["dir"] * physics_dt
                    if g.boss["x"] <= 10 or g.boss["x"] >= WIDTH - g.boss["w"] - 10:
                        g.boss["dir"] *= -1
                    g.boss["shoot"] += physics_dt
                    if g.boss["shoot"] > 0.45:
                        g.enemy_lasers.append([g.boss["x"] + 20, g.boss["y"] + g.boss["h"], 430.0])
                        g.enemy_lasers.append([g.boss["x"] + g.boss["w"] - 20, g.boss["y"] + g.boss["h"], 430.0])
                        g.boss["shoot"] = 0.0

                b_rect = pygame.Rect(int(g.boss["x"]), int(g.boss["y"]), int(g.boss["w"]), int(g.boss["h"]))
                for l in g.lasers[:]:
                    if b_rect.colliderect(pygame.Rect(int(l[0]), int(l[1]), l[6], l[7])):
                        g.boss["hp"] -= l[5]
                        g.spawn_particles(l[0], l[1], (255, 200, 100), 3)
                        if not l[8]:
                            if l in g.lasers: g.lasers.remove(l)
                        if g.boss["hp"] <= 0:
                            g.spawn_particles(g.boss["x"] + g.boss["w"]//2, g.boss["y"] + g.boss["h"]//2, BOSS_COLOR, 25)
                            g.score += 25
                            g.bombs += 1
                            g.ammo_crates.append([g.boss["x"] + g.boss["w"]//2, g.boss["y"], 180.0])
                            g.boss = None
                            break

            for enemy in g.enemies[:]:
                if g.timer_cryo_freeze <= 0:
                    enemy[1] += enemy[3] * physics_dt
                    enemy[4] -= physics_dt
                    if enemy[4] <= 0:
                        g.enemy_lasers.append([enemy[0] + enemy[2] // 2, enemy[1] + enemy[2], 370.0 * diff_factor])
                        enemy[4] = 999.0
                e_rect = pygame.Rect(int(enemy[0]), int(enemy[1]), int(enemy[2]), int(enemy[2]))

                for l in g.lasers[:]:
                    if e_rect.colliderect(pygame.Rect(int(l[0]), int(l[1]), l[6], l[7])):
                        g.spawn_particles(l[0], l[1], enemy[5], 4)
                        enemy[6] -= l[5]
                        if not l[8]:
                            if l in g.lasers: g.lasers.remove(l)
                        if enemy[6] <= 0:
                            g.spawn_particles(enemy[0] + enemy[2]//2, enemy[1] + enemy[2]//2, enemy[5], 10)
                            g.score += 2 if enemy[7] else 1
                            if enemy[7] and random.random() < 0.25:
                                g.ammo_crates.append([enemy[0] + 10, enemy[1], 200.0])
                            if enemy in g.enemies: g.enemies.remove(enemy)
                        break

                for mine in g.mines[:]:
                    if math.hypot(mine[0] - (enemy[0] + enemy[2]//2), mine[1] - (enemy[1] + enemy[2]//2)) < 35:
                        g.spawn_particles(mine[0], mine[1], (0, 255, 255), 15)
                        if enemy in g.enemies: g.enemies.remove(enemy)
                        if mine in g.mines: g.mines.remove(mine)
                        g.score += 1
                        break

                if e_rect.colliderect(player_rect):
                    if enemy in g.enemies: g.enemies.remove(enemy)
                    if g.timer_shield <= 0 and g.dash_timer <= 0:
                        g.hp -= 1
                        if g.hp <= 0: g.game_state = "GAMEOVER"
                elif enemy[1] > HEIGHT:
                    if enemy in g.enemies: g.enemies.remove(enemy)

            for ast in g.asteroids[:]:
                if g.timer_cryo_freeze <= 0:
                    ast[1] += ast[3] * physics_dt
                ast_rect = pygame.Rect(int(ast[0] - ast[2]), int(ast[1] - ast[2]), int(ast[2]*2), int(ast[2]*2))
                for l in g.lasers[:]:
                    if ast_rect.colliderect(pygame.Rect(int(l[0]), int(l[1]), l[6], l[7])):
                        g.spawn_particles(l[0], l[1], ASTEROID_COLOR, 3)
                        ast[4] -= l[5]
                        if not l[8]:
                            if l in g.lasers: g.lasers.remove(l)
                        if ast[4] <= 0:
                            g.spawn_particles(ast[0], ast[1], ASTEROID_COLOR, 6)
                            g.coins.append([ast[0], ast[1], 9, 200.0])
                            g.score += 2
                            if ast in g.asteroids: g.asteroids.remove(ast)
                        break
                if ast_rect.colliderect(player_rect):
                    if ast in g.asteroids: g.asteroids.remove(ast)
                    if g.timer_shield <= 0 and g.dash_timer <= 0:
                        g.hp -= 1
                        if g.hp <= 0: g.game_state = "GAMEOVER"
                elif ast[1] > HEIGHT + 40:
                    if ast in g.asteroids: g.asteroids.remove(ast)

            for el in g.enemy_lasers[:]:
                if player_rect.colliderect(pygame.Rect(int(el[0]), int(el[1]), 6, 12)):
                    g.enemy_lasers.remove(el)
                    if g.timer_shield <= 0 and g.dash_timer <= 0:
                        g.hp -= 1
                        if g.hp <= 0: g.game_state = "GAMEOVER"

            for c in g.coins[:]:
                if g.timer_magnet > 0:
                    dx, dy = (g.player_x + g.player_w // 2) - c[0], (g.player_y + g.player_h // 2) - c[1]
                    dist = math.hypot(dx, dy)
                    if dist > 0:
                        c[0] += (dx / dist) * 450.0 * dt
                        c[1] += (dy / dist) * 450.0 * dt
                c[1] += c[3] * dt
                if player_rect.colliderect(pygame.Rect(int(c[0] - c[2]), int(c[1] - c[2]), int(c[2]*2), int(c[2]*2))):
                    g.coins.remove(c)
                    g.coins_collected += 1
                    g.score += 1
                elif c[1] > HEIGHT: g.coins.remove(c)

            for pu in g.power_orbs[:]:
                pu[1] += pu[3] * dt
                if player_rect.colliderect(pygame.Rect(int(pu[0] - 14), int(pu[1] - 14), 28, 28)):
                    ptype = pu[2]
                    if ptype == "TRIPLE":
                        g.timer_triple_shot = 7.0
                        g.add_floating_text("TRIPLE CANNON!", g.player_x - 30, g.player_y - 20, (0, 255, 180))
                    elif ptype == "RAPID":
                        g.timer_rapid_fire = 6.0
                        g.add_floating_text("HYPER SPEED!", g.player_x - 30, g.player_y - 20, (0, 255, 255))
                    elif ptype == "SHIELD":
                        g.timer_shield = 8.0
                        g.add_floating_text("SHIELD ACTIVE!", g.player_x - 30, g.player_y - 20, SHIELD_COLOR)
                    elif ptype == "TIME_SLOW":
                        g.timer_time_slow = 6.0
                        g.add_floating_text("CHRONO SLOW!", g.player_x - 30, g.player_y - 20, (120, 220, 255))
                    elif ptype == "MAGNET":
                        g.timer_magnet = 8.0
                        g.add_floating_text("ORB MAGNET!", g.player_x - 30, g.player_y - 20, (255, 100, 255))
                    elif ptype == "PIERCE":
                        g.timer_piercing = 7.0
                        g.add_floating_text("PIERCING BEAM!", g.player_x - 30, g.player_y - 20, (100, 200, 255))
                    elif ptype == "INF_AMMO":
                        g.timer_infinite_ammo = 6.0
                        g.add_floating_text("INFINITE AMMO!", g.player_x - 30, g.player_y - 20, AMMO_COLOR)
                    elif ptype == "OVERDRIVE":
                        g.timer_overdrive = 5.0
                        g.add_floating_text("QUAD OVERDRIVE!", g.player_x - 30, g.player_y - 20, (255, 0, 255))
                    elif ptype == "CRYO":
                        g.timer_cryo_freeze = 4.0
                        g.add_floating_text("CRYO FREEZE!", g.player_x - 30, g.player_y - 20, (200, 240, 255))
                    elif ptype == "NUKE_PACK":
                        g.bombs += 1
                        g.add_floating_text("+1 NUKE BOMB", g.player_x - 30, g.player_y - 20, BOMB_COLOR)
                    g.power_orbs.remove(pu)
                elif pu[1] > HEIGHT: g.power_orbs.remove(pu)

            for a in g.ammo_crates[:]:
                a[1] += a[2] * dt
                if player_rect.colliderect(pygame.Rect(int(a[0] - 14), int(a[1] - 14), 28, 28)):
                    g.ammo_crates.remove(a)
                    g.primary_ammo += 50
                    g.secondary_ammo += 50
                    g.add_floating_text("+50 AMMO", g.player_x - 5, g.player_y - 20, AMMO_COLOR)
                elif a[1] > HEIGHT: g.ammo_crates.remove(a)

            for h in g.heals[:]:
                h[1] += h[2] * dt
                if player_rect.colliderect(pygame.Rect(int(h[0] - 14), int(h[1] - 14), 28, 28)):
                    g.heals.remove(h)
                    g.hp = min(g.max_hp, g.hp + 1)
                    g.add_floating_text("+1 HP REPAIR", g.player_x, g.player_y - 20, HEAL_COLOR)
                elif h[1] > HEIGHT: g.heals.remove(h)

        for star in g.stars:
            star[1] += star[2] * dt
            if star[1] > HEIGHT:
                star[1] = 0
                star[0] = random.randint(0, WIDTH)

        for p in g.particles[:]:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[4] -= dt
            if p[4] <= 0: g.particles.remove(p)

        for ft in g.floating_texts[:]:
            ft[2] -= 45.0 * dt
            ft[3] -= dt
            if ft[3] <= 0: g.floating_texts.remove(ft)

        screen.fill(BG_COLOR)

        for s in g.stars: pygame.draw.circle(screen, (170, 180, 230), (int(s[0]), int(s[1])), 1)
        for p in g.particles: pygame.draw.circle(screen, p[5], (int(p[0]), int(p[1])), int(max(1, p[4] * 10)))

        # RENDER AUTH MENU
        if g.game_state == "AUTH_MENU":
            title_txt = large_font.render("GALAXY STRIKER", True, WHITE)
            screen.blit(title_txt, (WIDTH // 2 - title_txt.get_width() // 2, 140))
            sub_txt = font.render("PILOT VAULT ACCESS", True, (0, 220, 255))
            screen.blit(sub_txt, (WIDTH // 2 - sub_txt.get_width() // 2, 180))

            pygame.draw.rect(screen, (0, 180, 120), g.btn_auth_login, border_radius=10)
            l_txt = large_font.render("LOGIN PILOT", True, WHITE)
            screen.blit(l_txt, (g.btn_auth_login.centerx - l_txt.get_width()//2, g.btn_auth_login.centery - l_txt.get_height()//2))

            pygame.draw.rect(screen, (50, 50, 80), g.btn_auth_signup, border_radius=10)
            s_txt = large_font.render("NEW PILOT SIGN UP", True, WHITE)
            screen.blit(s_txt, (g.btn_auth_signup.centerx - s_txt.get_width()//2, g.btn_auth_signup.centery - s_txt.get_height()//2))

        # RENDER LOGIN / SIGNUP SCREEN
        elif g.game_state in ["LOGIN_SCREEN", "SIGNUP_SCREEN"]:
            is_signup = (g.game_state == "SIGNUP_SCREEN")
            header_txt = large_font.render("SIGN UP PILOT" if is_signup else "PILOT LOGIN", True, WHITE)
            screen.blit(header_txt, (WIDTH // 2 - header_txt.get_width() // 2, 40))

            pygame.draw.rect(screen, (50, 50, 70), g.btn_auth_back, border_radius=6)
            screen.blit(font.render("< Back", True, WHITE), (g.btn_auth_back.centerx - 22, g.btn_auth_back.centery - 9))

            u_color = (0, 220, 255) if g.active_input_field == "USER" else (40, 40, 60)
            pygame.draw.rect(screen, (25, 25, 40), g.input_user_rect, border_radius=6)
            pygame.draw.rect(screen, u_color, g.input_user_rect, 2, border_radius=6)
            screen.blit(small_font.render("CALLSIGN (USERNAME):", True, (180, 180, 200)), (g.input_user_rect.x + 5, g.input_user_rect.y - 18))
            u_display = g.input_username + ("|" if g.active_input_field == "USER" else "")
            screen.blit(font.render(u_display, True, WHITE), (g.input_user_rect.x + 12, g.input_user_rect.centery - 8))

            p_color = (0, 220, 255) if g.active_input_field == "PIN" else (40, 40, 60)
            pygame.draw.rect(screen, (25, 25, 40), g.input_pin_rect, border_radius=6)
            pygame.draw.rect(screen, p_color, g.input_pin_rect, 2, border_radius=6)
            screen.blit(small_font.render("4-DIGIT PIN (PASSWORD):", True, (180, 180, 200)), (g.input_pin_rect.x + 5, g.input_pin_rect.y - 18))
            pin_mask = ("*" * len(g.input_pin)) + ("|" if g.active_input_field == "PIN" else "")
            screen.blit(font.render(pin_mask, True, WHITE), (g.input_pin_rect.x + 12, g.input_pin_rect.centery - 8))

            pygame.draw.rect(screen, (0, 200, 120), g.btn_submit_auth, border_radius=8)
            sub_name = "CREATE PILOT" if is_signup else "ENTER FLEET"
            btn_t = font.render(sub_name, True, WHITE)
            screen.blit(btn_t, (g.btn_submit_auth.centerx - btn_t.get_width()//2, g.btn_submit_auth.centery - btn_t.get_height()//2))

            if g.auth_error_msg:
                err_t = font.render(g.auth_error_msg, True, HEALTH_RED)
                screen.blit(err_t, (WIDTH // 2 - err_t.get_width() // 2, 415))

            for key_char, k_rect in g.keypad_rects:
                btn_c = (50, 50, 70) if key_char not in ["CLR", "DEL"] else (80, 40, 40)
                pygame.draw.rect(screen, btn_c, k_rect, border_radius=4)
                kt = small_font.render(key_char, True, WHITE)
                screen.blit(kt, (k_rect.centerx - kt.get_width() // 2, k_rect.centery - kt.get_height() // 2))

        # RENDER GARAGE
        elif g.game_state == "GARAGE":
            title_txt = large_font.render("STARGARAGE", True, WHITE)
            screen.blit(title_txt, (WIDTH // 2 - title_txt.get_width() // 2, 20))

            user_badge = font.render(f"Pilot: {g.current_user}", True, (0, 220, 255))
            screen.blit(user_badge, (40, 60))

            bank_txt = font.render(f"Orbs: {g.total_banked_orbs}", True, COIN_COLOR)
            screen.blit(bank_txt, (WIDTH - 150, 60))

            pygame.draw.rect(screen, (70, 30, 40), g.logout_btn, border_radius=6)
            screen.blit(small_font.render("LOGOUT", True, WHITE), (g.logout_btn.centerx - 22, g.logout_btn.centery - 6))

            cur_sk = g.skins[g.equipped_skin_idx]
            pygame.draw.rect(screen, (40, 40, 70), g.skin_menu_btn, border_radius=8)
            screen.blit(font.render(f"Hangar: {cur_sk['name']}", True, WHITE), (g.skin_menu_btn.x + 15, g.skin_menu_btn.centery - 9))

            cur_pri = g.primary_weapons[g.equipped_primary_idx]
            pygame.draw.rect(screen, (40, 40, 70), g.primary_menu_btn, border_radius=8)
            screen.blit(font.render(f"Primary: {cur_pri['name']}", True, (0, 220, 255)), (g.primary_menu_btn.x + 15, g.primary_menu_btn.centery - 9))

            cur_sec = g.secondary_weapons[g.equipped_sec_idx]
            pygame.draw.rect(screen, (40, 40, 70), g.sec_menu_btn, border_radius=8)
            screen.blit(font.render(f"Secondary: {cur_sec['name']}", True, (255, 180, 0)), (g.sec_menu_btn.x + 15, g.sec_menu_btn.centery - 9))

            pygame.draw.rect(screen, (35, 35, 55), g.armor_btn, border_radius=8)
            screen.blit(font.render(f"Shield Hull (Lv {g.armor_level}) - Cost: 25 Orbs", True, WHITE), (g.armor_btn.x + 15, g.armor_btn.centery - 9))

            pygame.draw.rect(screen, (35, 35, 55), g.speed_btn, border_radius=8)
            screen.blit(font.render(f"Thrusters (Lv {g.speed_level}) - Cost: 25 Orbs", True, WHITE), (g.speed_btn.x + 15, g.speed_btn.centery - 9))

            pygame.draw.rect(screen, (35, 35, 55), g.damage_btn, border_radius=8)
            screen.blit(font.render(f"Damage Amp (Lv {g.damage_level}) - Cost: 25 Orbs", True, WHITE), (g.damage_btn.x + 15, g.damage_btn.centery - 9))

            g.draw_custom_ship(screen, WIDTH // 2, 510, cur_sk, scale=1.3)

            pygame.draw.rect(screen, (0, 200, 120), g.launch_btn_rect, border_radius=10)
            launch_txt = large_font.render("LAUNCH MISSION", True, WHITE)
            screen.blit(launch_txt, (g.launch_btn_rect.centerx - launch_txt.get_width()//2, g.launch_btn_rect.centery - launch_txt.get_height()//2))

        # RENDER SKIN SHOP
        elif g.game_state == "SKIN_SHOP":
            t_txt = large_font.render("SHIP HANGAR", True, WHITE)
            screen.blit(t_txt, (WIDTH // 2 - t_txt.get_width() // 2, 35))

            b_txt = font.render(f"Banked Orbs: {g.total_banked_orbs}", True, COIN_COLOR)
            screen.blit(b_txt, (WIDTH // 2 - b_txt.get_width() // 2, 80))

            pygame.draw.rect(screen, (50, 50, 70), g.back_garage_btn, border_radius=6)
            screen.blit(font.render("< Back", True, WHITE), (g.back_garage_btn.centerx - 22, g.back_garage_btn.centery - 9))

            cur_sk = g.skins[g.viewing_skin_idx]
            g.draw_custom_ship(screen, WIDTH // 2, 280, cur_sk, scale=2.0)

            s_name = large_font.render(cur_sk["name"], True, cur_sk["primary"] if cur_sk["unlocked"] else WHITE)
            screen.blit(s_name, (WIDTH // 2 - s_name.get_width() // 2, 360))

            is_equipped = (g.viewing_skin_idx == g.equipped_skin_idx)
            if is_equipped:
                status_str = "CURRENTLY EQUIPPED"
                stat_col = (0, 255, 200)
            elif cur_sk["unlocked"]:
                status_str = "UNLOCKED - TAP TO EQUIP"
                stat_col = HEALTH_GREEN
            else:
                status_str = f"COST: {cur_sk['cost']} ORBS"
                stat_col = COIN_COLOR

            s_stat = font.render(status_str, True, stat_col)
            screen.blit(s_stat, (WIDTH // 2 - s_stat.get_width() // 2, 410))

            pygame.draw.rect(screen, (40, 40, 60), g.shop_prev_btn, border_radius=8)
            pygame.draw.rect(screen, (40, 40, 60), g.shop_next_btn, border_radius=8)
            screen.blit(large_font.render("<", True, WHITE), (g.shop_prev_btn.centerx - 8, g.shop_prev_btn.centery - 15))
            screen.blit(large_font.render(">", True, WHITE), (g.shop_next_btn.centerx - 8, g.shop_next_btn.centery - 15))

            if not cur_sk["unlocked"]:
                pygame.draw.rect(screen, (200, 140, 0), g.shop_action_btn, border_radius=8)
                buy_txt = large_font.render("UNLOCK SHIP", True, WHITE)
                screen.blit(buy_txt, (g.shop_action_btn.centerx - buy_txt.get_width()//2, g.shop_action_btn.centery - buy_txt.get_height()//2))
            elif not is_equipped:
                pygame.draw.rect(screen, (0, 180, 120), g.shop_action_btn, border_radius=8)
                eq_txt = large_font.render("EQUIP SHIP", True, WHITE)
                screen.blit(eq_txt, (g.shop_action_btn.centerx - eq_txt.get_width()//2, g.shop_action_btn.centery - eq_txt.get_height()//2))

        # RENDER PRIMARY WEAPONS SHOP
        elif g.game_state == "PRI_SHOP":
            t_txt = large_font.render("PRIMARY ARSENAL", True, WHITE)
            screen.blit(t_txt, (WIDTH // 2 - t_txt.get_width() // 2, 35))

            b_txt = font.render(f"Banked Orbs: {g.total_banked_orbs}", True, COIN_COLOR)
            screen.blit(b_txt, (WIDTH // 2 - b_txt.get_width() // 2, 80))

            pygame.draw.rect(screen, (50, 50, 70), g.back_garage_btn, border_radius=6)
            screen.blit(font.render("< Back", True, WHITE), (g.back_garage_btn.centerx - 22, g.back_garage_btn.centery - 9))

            cur_pri = g.primary_weapons[g.viewing_primary_idx]
            s_name = large_font.render(cur_pri["name"], True, (0, 220, 255))
            screen.blit(s_name, (WIDTH // 2 - s_name.get_width() // 2, 280))

            is_equipped = (g.viewing_primary_idx == g.equipped_primary_idx)
            if is_equipped:
                status_str = "CURRENTLY EQUIPPED"
                stat_col = (0, 255, 200)
            elif cur_pri["unlocked"]:
                status_str = "UNLOCKED - TAP TO EQUIP"
                stat_col = HEALTH_GREEN
            else:
                status_str = f"COST: {cur_pri['cost']} ORBS"
                stat_col = COIN_COLOR

            s_stat = font.render(status_str, True, stat_col)
            screen.blit(s_stat, (WIDTH // 2 - s_stat.get_width() // 2, 330))

            pygame.draw.rect(screen, (40, 40, 60), g.shop_prev_btn, border_radius=8)
            pygame.draw.rect(screen, (40, 40, 60), g.shop_next_btn, border_radius=8)
            screen.blit(large_font.render("<", True, WHITE), (g.shop_prev_btn.centerx - 8, g.shop_prev_btn.centery - 15))
            screen.blit(large_font.render(">", True, WHITE), (g.shop_next_btn.centerx - 8, g.shop_next_btn.centery - 15))

            if not cur_pri["unlocked"]:
                pygame.draw.rect(screen, (200, 140, 0), g.shop_action_btn, border_radius=8)
                buy_txt = large_font.render("UNLOCK WEAPON", True, WHITE)
                screen.blit(buy_txt, (g.shop_action_btn.centerx - buy_txt.get_width()//2, g.shop_action_btn.centery - buy_txt.get_height()//2))
            elif not is_equipped:
                pygame.draw.rect(screen, (0, 180, 120), g.shop_action_btn, border_radius=8)
                eq_txt = large_font.render("EQUIP WEAPON", True, WHITE)
                screen.blit(eq_txt, (g.shop_action_btn.centerx - eq_txt.get_width()//2, g.shop_action_btn.centery - eq_txt.get_height()//2))

        # RENDER SECONDARY SHOP
        elif g.game_state == "SEC_SHOP":
            t_txt = large_font.render("SECONDARY WEAPONS", True, WHITE)
            screen.blit(t_txt, (WIDTH // 2 - t_txt.get_width() // 2, 35))

            b_txt = font.render(f"Banked Orbs: {g.total_banked_orbs}", True, COIN_COLOR)
            screen.blit(b_txt, (WIDTH // 2 - b_txt.get_width() // 2, 80))

            pygame.draw.rect(screen, (50, 50, 70), g.back_garage_btn, border_radius=6)
            screen.blit(font.render("< Back", True, WHITE), (g.back_garage_btn.centerx - 22, g.back_garage_btn.centery - 9))

            cur_sec = g.secondary_weapons[g.viewing_sec_idx]
            s_name = large_font.render(cur_sec["name"], True, (255, 180, 0))
            screen.blit(s_name, (WIDTH // 2 - s_name.get_width() // 2, 280))

            is_equipped = (g.viewing_sec_idx == g.equipped_sec_idx)
            if is_equipped:
                status_str = "CURRENTLY EQUIPPED"
                stat_col = (0, 255, 200)
            elif cur_sec["unlocked"]:
                status_str = "UNLOCKED - TAP TO EQUIP"
                stat_col = HEALTH_GREEN
            else:
                status_str = f"COST: {cur_sec['cost']} ORBS"
                stat_col = COIN_COLOR

            s_stat = font.render(status_str, True, stat_col)
            screen.blit(s_stat, (WIDTH // 2 - s_stat.get_width() // 2, 330))

            pygame.draw.rect(screen, (40, 40, 60), g.shop_prev_btn, border_radius=8)
            pygame.draw.rect(screen, (40, 40, 60), g.shop_next_btn, border_radius=8)
            screen.blit(large_font.render("<", True, WHITE), (g.shop_prev_btn.centerx - 8, g.shop_prev_btn.centery - 15))
            screen.blit(large_font.render(">", True, WHITE), (g.shop_next_btn.centerx - 8, g.shop_next_btn.centery - 15))

            if not cur_sec["unlocked"]:
                pygame.draw.rect(screen, (200, 140, 0), g.shop_action_btn, border_radius=8)
                buy_txt = large_font.render("UNLOCK WEAPON", True, WHITE)
                screen.blit(buy_txt, (g.shop_action_btn.centerx - buy_txt.get_width()//2, g.shop_action_btn.centery - buy_txt.get_height()//2))
            elif not is_equipped:
                pygame.draw.rect(screen, (0, 180, 120), g.shop_action_btn, border_radius=8)
                eq_txt = large_font.render("EQUIP WEAPON", True, WHITE)
                screen.blit(eq_txt, (g.shop_action_btn.centerx - eq_txt.get_width()//2, g.shop_action_btn.centery - eq_txt.get_height()//2))

        # RENDER PLAYING
        elif g.game_state == "PLAYING":
            for l in g.lasers: pygame.draw.rect(screen, l[4], (int(l[0]), int(l[1]), l[6], l[7]), border_radius=2)
            for m in g.missiles: pygame.draw.circle(screen, (50, 255, 120), (int(m[0]), int(m[1])), 4)
            for mine in g.mines: 
                pygame.draw.circle(screen, (0, 255, 255), (int(mine[0]), int(mine[1])), 7)
                pygame.draw.circle(screen, (255, 255, 255), (int(mine[0]), int(mine[1])), 3)
            for el in g.enemy_lasers: pygame.draw.rect(screen, (255, 120, 30), (int(el[0]), int(el[1]), 6, 14), border_radius=2)

            if g.timer_shield > 0 or g.dash_timer > 0:
                pygame.draw.circle(screen, SHIELD_COLOR, (int(g.player_x + g.player_w // 2), int(g.player_y + g.player_h // 2)), int(g.player_w * 0.8), 2)

            cur_sk = g.skins[g.equipped_skin_idx]
            g.draw_custom_ship(screen, int(g.player_x + g.player_w // 2), int(g.player_y + g.player_h // 2), cur_sk, scale=1.0)

            if g.boss:
                pygame.draw.rect(screen, BOSS_COLOR, (int(g.boss["x"]), int(g.boss["y"]), int(g.boss["w"]), int(g.boss["h"])), border_radius=6)
                pygame.draw.polygon(screen, (255, 100, 100), [
                    (int(g.boss["x"] + g.boss["w"] // 2), int(g.boss["y"] - 15)),
                    (int(g.boss["x"] + 10), int(g.boss["y"])),
                    (int(g.boss["x"] + g.boss["w"] - 10), int(g.boss["y"]))
                ])
                pygame.draw.rect(screen, HEALTH_GREEN, (int(g.boss["x"]), int(g.boss["y"] - 22), int(g.boss["w"] * (g.boss["hp"] / g.boss["max_hp"])), 6))

            for ast in g.asteroids:
                pygame.draw.circle(screen, ASTEROID_COLOR, (int(ast[0]), int(ast[1])), int(ast[2]))

            for e in g.enemies:
                ex, ey, ew = int(e[0]), int(e[1]), int(e[2])
                col = (100, 200, 255) if g.timer_cryo_freeze > 0 else e[5]
                pygame.draw.polygon(screen, col, [
                    (ex + ew//2, ey + ew if not e[7] else ey),
                    (ex, ey + (0 if e[7] else ew)),
                    (ex + ew, ey + (0 if e[7] else ew))
                ])

            for c in g.coins: pygame.draw.circle(screen, COIN_COLOR, (int(c[0]), int(c[1])), int(c[2]))
            
            for pu in g.power_orbs:
                px_pos, py_pos = int(pu[0]), int(pu[1])
                pygame.draw.circle(screen, (255, 0, 255), (px_pos, py_pos), 13)
                pygame.draw.circle(screen, WHITE, (px_pos, py_pos), 9)
                pygame.draw.circle(screen, (0, 255, 255), (px_pos, py_pos), 5)

            for a in g.ammo_crates:
                ax, ay = int(a[0]), int(a[1])
                pygame.draw.rect(screen, AMMO_COLOR, (ax - 12, ay - 12, 24, 24), border_radius=3)
                pygame.draw.rect(screen, WHITE, (ax - 4, ay - 8, 8, 16), border_radius=2)

            for h in g.heals:
                hx, hy = int(h[0]), int(h[1])
                pygame.draw.circle(screen, HEAL_COLOR, (hx, hy), 12)
                pygame.draw.rect(screen, WHITE, (hx - 2, hy - 7, 4, 14))
                pygame.draw.rect(screen, WHITE, (hx - 7, hy - 2, 14, 4))

            fire_btn_col = HEALTH_RED if (g.is_overheated or (g.primary_ammo <= 0 and g.timer_infinite_ammo <= 0)) else (0, 200, 255)
            pygame.draw.circle(screen, (30, 30, 45), (g.fire_btn_rect.centerx, g.fire_btn_rect.centery), g.fire_btn_rect.width // 2)
            pygame.draw.circle(screen, fire_btn_col, (g.fire_btn_rect.centerx, g.fire_btn_rect.centery), g.fire_btn_rect.width // 2 - 2, 2)
            f_txt = font.render("FIRE", True, fire_btn_col)
            screen.blit(f_txt, (g.fire_btn_rect.centerx - f_txt.get_width() // 2, g.fire_btn_rect.centery - f_txt.get_height() // 2))

            pygame.draw.circle(screen, (35, 35, 50), (g.bomb_btn_rect.centerx, g.bomb_btn_rect.centery), g.bomb_btn_rect.width // 2)
            pygame.draw.circle(screen, BOMB_COLOR, (g.bomb_btn_rect.centerx, g.bomb_btn_rect.centery), g.bomb_btn_rect.width // 2 - 2, 2)
            b_txt = font.render(f"NUKE:{g.bombs}", True, BOMB_COLOR)
            screen.blit(b_txt, (g.bomb_btn_rect.centerx - b_txt.get_width() // 2, g.bomb_btn_rect.centery - b_txt.get_height() // 2))

            pygame.draw.circle(screen, (35, 35, 50), (g.dash_btn_rect.centerx, g.dash_btn_rect.centery), g.dash_btn_rect.width // 2)
            pygame.draw.circle(screen, DASH_COLOR, (g.dash_btn_rect.centerx, g.dash_btn_rect.centery), g.dash_btn_rect.width // 2 - 2, 2)
            d_txt = font.render("WARP", True, DASH_COLOR)
            screen.blit(d_txt, (g.dash_btn_rect.centerx - d_txt.get_width() // 2, g.dash_btn_rect.centery - d_txt.get_height() // 2))

            screen.blit(font.render(f"LEVEL: {g.current_level}", True, (0, 255, 200)), (15, 15))
            screen.blit(font.render(f"Score: {g.score}", True, WHITE), (15, 35))
            screen.blit(font.render(f"Orbs: {g.coins_collected}", True, COIN_COLOR), (15, 55))
            ammo_disp = "INF" if g.timer_infinite_ammo > 0 else str(g.primary_ammo)
            screen.blit(font.render(f"Pri Ammo: {ammo_disp}", True, AMMO_COLOR if g.primary_ammo > 20 or g.timer_infinite_ammo > 0 else HEALTH_RED), (15, 75))
            sec_disp = "INF" if g.timer_infinite_ammo > 0 else str(g.secondary_ammo)
            screen.blit(font.render(f"Sec Ammo: {sec_disp}", True, (255, 180, 0)), (15, 95))

            for ft in g.floating_texts:
                screen.blit(font.render(ft[0], True, ft[4]), (int(ft[1]), int(ft[2])))

            pygame.draw.rect(screen, HEALTH_RED, (WIDTH - 140, 20, 120, 12), border_radius=3)
            pygame.draw.rect(screen, HEALTH_GREEN, (WIDTH - 140, 20, int(120 * (g.hp / g.max_hp)), 12), border_radius=3)

        # RENDER GAMEOVER
        elif g.game_state == "GAMEOVER":
            over_text = large_font.render("FLEET DESTROYED", True, (255, 60, 90))
            screen.blit(over_text, (WIDTH // 2 - over_text.get_width() // 2, HEIGHT // 3))

            score_final = font.render(f"Level: {g.current_level} | Score: {g.score} | Banked Orbs: +{g.coins_collected}", True, WHITE)
            screen.blit(score_final, (WIDTH // 2 - score_final.get_width() // 2, HEIGHT // 3 + 50))

            pygame.draw.rect(screen, (0, 180, 120), g.restart_btn_rect, border_radius=8)
            r_txt = font.render("BANK ORBS & HANGAR", True, WHITE)
            screen.blit(r_txt, (g.restart_btn_rect.centerx - r_txt.get_width() // 2, g.restart_btn_rect.centery - r_txt.get_height() // 2))

        pygame.display.flip()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())