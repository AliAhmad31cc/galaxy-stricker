import pygame
import random
import math
import asyncio
import sys

pygame.init()
pygame.font.init()

WIDTH, HEIGHT = 450, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Galaxy Striker")
clock = pygame.time.Clock()

BG_COLOR = (8, 8, 24)
PLAYER_COLOR = (0, 220, 255)
LASER_COLOR = (0, 255, 180)
BEAM_COLOR = (0, 255, 255)
ENEMY_COLOR = (255, 60, 90)
ELITE_COLOR = (200, 50, 255)
ENEMY_LASER_COLOR = (255, 120, 30)
BOSS_COLOR = (255, 30, 30)
COIN_COLOR = (255, 215, 0)
ASTEROID_COLOR = (140, 140, 160)
TRIPLE_COLOR = (180, 70, 255)
RAPID_COLOR = (0, 255, 255)
SHIELD_COLOR = (255, 200, 50)
BOMB_COLOR = (255, 80, 0)
DASH_COLOR = (0, 255, 180)
MISSILE_COLOR = (50, 255, 120)
HEAL_COLOR = (50, 255, 100)
MAGNET_COLOR = (255, 100, 255)
PIERCE_COLOR = (100, 200, 255)
OVERCHARGE_COLOR = (0, 255, 255)
TIME_SLOW_COLOR = (100, 255, 255)
HEAT_COLOR = (255, 100, 20)
WHITE = (255, 255, 255)
HEALTH_GREEN = (50, 220, 90)
HEALTH_RED = (200, 40, 40)

font = pygame.font.Font(None, 24)
large_font = pygame.font.Font(None, 40)

async def main():
    player_w, player_h = 44, 44
    player_x = float(WIDTH // 2 - player_w // 2)
    player_y = float(HEIGHT - player_h - 130)
    
    total_banked_orbs = 50 
    
    skins = [
        {"name": "Default Viper", "color": (0, 220, 255), "cost": 0, "unlocked": True},
        {"name": "Crimson Hawk", "color": (255, 50, 50), "cost": 10, "unlocked": False},
        {"name": "Gold Sentinel", "color": (255, 215, 0), "cost": 25, "unlocked": False},
        {"name": "Neon Phantom", "color": (200, 50, 255), "cost": 40, "unlocked": False},
        {"name": "Emerald Stalker", "color": (50, 255, 100), "cost": 60, "unlocked": False},
        {"name": "Solar Flare", "color": (255, 140, 0), "cost": 80, "unlocked": False},
        {"name": "Void Reaver", "color": (100, 100, 120), "cost": 100, "unlocked": False},
        {"name": "Cyber Ghost", "color": (0, 255, 200), "cost": 120, "unlocked": False},
        {"name": "Ruby Corsair", "color": (220, 20, 60), "cost": 150, "unlocked": False},
        {"name": "Sapphire Knight", "color": (30, 144, 255), "cost": 180, "unlocked": False},
        {"name": "Amethyst Lord", "color": (153, 50, 204), "cost": 210, "unlocked": False},
        {"name": "Titanium Core", "color": (192, 192, 192), "cost": 250, "unlocked": False},
        {"name": "Plasma Beast", "color": (255, 0, 255), "cost": 300, "unlocked": False},
        {"name": "Acid Viper", "color": (124, 252, 0), "cost": 350, "unlocked": False},
        {"name": "Frostbite", "color": (175, 238, 238), "cost": 400, "unlocked": False},
        {"name": "Magma Striker", "color": (255, 69, 0), "cost": 450, "unlocked": False},
        {"name": "Shadow Fiend", "color": (75, 0, 130), "cost": 500, "unlocked": False},
        {"name": "Supernova", "color": (255, 255, 255), "cost": 600, "unlocked": False},
        {"name": "Quantum Glitch", "color": (0, 255, 127), "cost": 750, "unlocked": False},
        {"name": "Galaxy Emperor", "color": (255, 215, 0), "cost": 1000, "unlocked": False}
    ]
    selected_skin_idx = 0

    armor_level = 1
    speed_level = 1
    damage_level = 1
    
    primary_weapons = ["PLASMA", "PULSE", "SCATTER", "BEAM"]
    primary_idx = 0
    secondary_weapons = ["NONE", "HOMING MISSILES", "EMP MINES", "ORBITAL LASER"]
    secondary_idx = 0

    max_hp = 5
    hp = max_hp
    bombs = 2
    dash_charges = 2

    heat = 0.0
    max_heat = 100.0
    is_overheated = False
    overheat_cooldown = 0.0
    fire_cooldown = 0.0

    triple_shot_timer = 0.0
    rapid_fire_timer = 0.0
    shield_timer = 0.0
    missile_timer = 0.0
    missile_shoot_timer = 0.0
    overcharge_timer = 0.0
    magnet_timer = 0.0
    pierce_timer = 0.0
    dash_timer = 0.0
    time_slow_timer = 0.0

    combo_count = 0
    combo_timer = 0.0

    lasers = []
    missiles = []
    enemy_lasers = []
    enemies = []
    asteroids = []
    coins = []
    powerups = []
    particles = []
    floating_texts = []
    boss = None

    score = 0
    coins_collected = 0
    game_state = "GARAGE"
    enemy_timer = 0.0
    asteroid_timer = 0.0
    coin_timer = 0.0
    powerup_timer = 0.0

    stars = [[random.randint(0, WIDTH), random.randint(0, HEIGHT), random.randint(140, 300)] for _ in range(45)]
    
    fire_btn_rect = pygame.Rect(WIDTH - 85, HEIGHT - 105, 75, 75)
    bomb_btn_rect = pygame.Rect(WIDTH - 170, HEIGHT - 105, 75, 75)
    dash_btn_rect = pygame.Rect(WIDTH - 255, HEIGHT - 105, 75, 75)
    
    skin_menu_btn = pygame.Rect(40, 150, 370, 45)
    armor_btn = pygame.Rect(40, 210, 370, 40)
    speed_btn = pygame.Rect(40, 260, 370, 40)
    damage_btn = pygame.Rect(40, 310, 370, 40)
    primary_wep_btn = pygame.Rect(40, 370, 370, 40)
    secondary_wep_btn = pygame.Rect(40, 420, 370, 40)
    launch_btn_rect = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 120, 220, 50)

    back_garage_btn = pygame.Rect(40, 40, 120, 40)
    skin_prev_btn = pygame.Rect(40, HEIGHT // 2 - 30, 60, 60)
    skin_next_btn = pygame.Rect(WIDTH - 100, HEIGHT // 2 - 30, 60, 60)
    skin_buy_btn = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 150, 220, 50)
    restart_btn_rect = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2 + 60, 240, 55)

    active_touches = {}

    def spawn_particles(x, y, color, count=6):
        for _ in range(count):
            particles.append([x, y, random.uniform(-180, 180), random.uniform(-180, 180), random.uniform(0.2, 0.45), color])

    def add_floating_text(text, x, y, color):
        floating_texts.append([text, x, y, 0.6, color])

    def trigger_nuke():
        nonlocal bombs, score, boss
        if bombs > 0:
            bombs -= 1
            add_floating_text("MEGA NUKE!", WIDTH // 2 - 60, HEIGHT // 2, BOMB_COLOR)
            for e in enemies:
                spawn_particles(e[0] + e[2]//2, e[1] + e[2]//2, e[5], 8)
                score += 1
            enemies.clear()
            asteroids.clear()
            enemy_lasers.clear()
            if boss:
                boss["hp"] -= 20

    def trigger_dash():
        nonlocal dash_charges, dash_timer
        if dash_charges > 0:
            dash_charges -= 1
            dash_timer = 0.35
            add_floating_text("DASH!", WIDTH // 2 - 30, HEIGHT // 2, DASH_COLOR)

    def start_game_session():
        nonlocal hp, max_hp, player_x, bombs, dash_charges, heat, is_overheated, boss, score, coins_collected
        nonlocal triple_shot_timer, rapid_fire_timer, shield_timer, missile_timer, overcharge_timer
        nonlocal magnet_timer, pierce_timer, dash_timer, time_slow_timer
        nonlocal combo_count, combo_timer, game_state, last_time
        max_hp = 4 + armor_level
        hp = max_hp
        player_x = float(WIDTH // 2 - player_w // 2)
        bombs = 2
        dash_charges = 2
        heat = 0.0
        is_overheated = False
        boss = None
        score = 0
        coins_collected = 0
        combo_count = 0
        combo_timer = 0.0
        triple_shot_timer = 0.0
        rapid_fire_timer = 0.0
        shield_timer = 0.0
        missile_timer = 0.0
        overcharge_timer = 0.0
        magnet_timer = 0.0
        pierce_timer = 0.0
        dash_timer = 0.0
        time_slow_timer = 0.0
        lasers.clear()
        missiles.clear()
        enemy_lasers.clear()
        enemies.clear()
        asteroids.clear()
        coins.clear()
        powerups.clear()
        particles.clear()
        floating_texts.clear()
        active_touches.clear()
        last_time = pygame.time.get_ticks()
        game_state = "PLAYING"

    last_time = pygame.time.get_ticks()

    running = True
    while running:
        current_time = pygame.time.get_ticks()
        dt = (current_time - last_time) / 1000.0
        last_time = current_time
        dt = min(dt, 0.05)
        physics_dt = dt * 0.5 if time_slow_timer > 0 else dt

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.FINGERDOWN:
                tx, ty = int(event.x * WIDTH), int(event.y * HEIGHT)
                active_touches[event.finger_id] = (tx, ty)
                if game_state == "GARAGE":
                    if skin_menu_btn.collidepoint((tx, ty)):
                        game_state = "SKINS"
                    elif armor_btn.collidepoint((tx, ty)) and total_banked_orbs >= 5:
                        total_banked_orbs -= 5
                        armor_level += 1
                    elif speed_btn.collidepoint((tx, ty)) and total_banked_orbs >= 5:
                        total_banked_orbs -= 5
                        speed_level += 1
                    elif damage_btn.collidepoint((tx, ty)) and total_banked_orbs >= 5:
                        total_banked_orbs -= 5
                        damage_level += 1
                    elif primary_wep_btn.collidepoint((tx, ty)):
                        primary_idx = (primary_idx + 1) % len(primary_weapons)
                    elif secondary_wep_btn.collidepoint((tx, ty)):
                        secondary_idx = (secondary_idx + 1) % len(secondary_weapons)
                    elif launch_btn_rect.collidepoint((tx, ty)):
                        start_game_session()
                elif game_state == "SKINS":
                    if back_garage_btn.collidepoint((tx, ty)):
                        game_state = "GARAGE"
                    elif skin_prev_btn.collidepoint((tx, ty)):
                        selected_skin_idx = (selected_skin_idx - 1) % len(skins)
                    elif skin_next_btn.collidepoint((tx, ty)):
                        selected_skin_idx = (selected_skin_idx + 1) % len(skins)
                    elif skin_buy_btn.collidepoint((tx, ty)):
                        sk = skins[selected_skin_idx]
                        if not sk["unlocked"] and total_banked_orbs >= sk["cost"]:
                            total_banked_orbs -= sk["cost"]
                            sk["unlocked"] = True
                elif game_state == "GAMEOVER":
                    if restart_btn_rect.collidepoint((tx, ty)):
                        total_banked_orbs += coins_collected
                        game_state = "GARAGE"
                elif game_state == "PLAYING":
                    if bomb_btn_rect.collidepoint((tx, ty)):
                        trigger_nuke()
                    elif dash_btn_rect.collidepoint((tx, ty)):
                        trigger_dash()
            elif event.type == pygame.FINGERMOTION:
                tx, ty = int(event.x * WIDTH), int(event.y * HEIGHT)
                active_touches[event.finger_id] = (tx, ty)
            elif event.type == pygame.FINGERUP:
                if event.finger_id in active_touches:
                    del active_touches[event.finger_id]
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                active_touches['mouse'] = pos
                if game_state == "GARAGE":
                    if skin_menu_btn.collidepoint(pos):
                        game_state = "SKINS"
                    elif armor_btn.collidepoint(pos) and total_banked_orbs >= 5:
                        total_banked_orbs -= 5
                        armor_level += 1
                    elif speed_btn.collidepoint(pos) and total_banked_orbs >= 5:
                        total_banked_orbs -= 5
                        speed_level += 1
                    elif damage_btn.collidepoint(pos) and total_banked_orbs >= 5:
                        total_banked_orbs -= 5
                        damage_level += 1
                    elif primary_wep_btn.collidepoint(pos):
                        primary_idx = (primary_idx + 1) % len(primary_weapons)
                    elif secondary_wep_btn.collidepoint(pos):
                        secondary_idx = (secondary_idx + 1) % len(secondary_weapons)
                    elif launch_btn_rect.collidepoint(pos):
                        start_game_session()
                elif game_state == "SKINS":
                    if back_garage_btn.collidepoint(pos):
                        game_state = "GARAGE"
                    elif skin_prev_btn.collidepoint(pos):
                        selected_skin_idx = (selected_skin_idx - 1) % len(skins)
                    elif skin_next_btn.collidepoint(pos):
                        selected_skin_idx = (selected_skin_idx + 1) % len(skins)
                    elif skin_buy_btn.collidepoint(pos):
                        sk = skins[selected_skin_idx]
                        if not sk["unlocked"] and total_banked_orbs >= sk["cost"]:
                            total_banked_orbs -= sk["cost"]
                            sk["unlocked"] = True
                elif game_state == "GAMEOVER":
                    if restart_btn_rect.collidepoint(pos):
                        total_banked_orbs += coins_collected
                        game_state = "GARAGE"
                elif game_state == "PLAYING":
                    if bomb_btn_rect.collidepoint(pos):
                        trigger_nuke()
                    elif dash_btn_rect.collidepoint(pos):
                        trigger_dash()
            elif event.type == pygame.MOUSEMOTION:
                if 'mouse' in active_touches:
                    active_touches['mouse'] = pygame.mouse.get_pos()
            elif event.type == pygame.MOUSEBUTTONUP:
                if 'mouse' in active_touches:
                    del active_touches['mouse']

        if game_state == "PLAYING":
            is_touching_fire = False
            is_moving = False
            move_target_x = player_x

            for tid, pos in active_touches.items():
                if fire_btn_rect.collidepoint(pos):
                    is_touching_fire = True
                elif bomb_btn_rect.collidepoint(pos) or dash_btn_rect.collidepoint(pos):
                    pass
                else:
                    is_moving = True
                    move_target_x = pos[0] - player_w // 2

            if is_moving:
                base_spd = 28.0 + (speed_level * 4.0)
                current_speed = base_spd * (2.2 if dash_timer > 0 else 1.0)
                player_x += (move_target_x - player_x) * min(1.0, current_speed * physics_dt)
                player_x = max(0.0, min(float(WIDTH - player_w), player_x))

            if combo_timer > 0:
                combo_timer -= physics_dt
            else:
                combo_count = 0

            if is_overheated:
                overheat_cooldown -= physics_dt
                heat = (overheat_cooldown / 1.2) * 100.0
                if overheat_cooldown <= 0:
                    is_overheated = False
                    heat = 0.0
            else:
                if not is_touching_fire and heat > 0:
                    heat = max(0.0, heat - 55.0 * physics_dt)

            base_cd = 0.06 if rapid_fire_timer > 0 else 0.12
            if fire_cooldown > 0:
                fire_cooldown -= physics_dt

            if is_touching_fire and not is_overheated and fire_cooldown <= 0:
                cx = player_x + player_w // 2 - 2
                piercing_flag = (pierce_timer > 0)
                w_type = primary_weapons[primary_idx]
                dmg_bonus = damage_level

                if triple_shot_timer > 0:
                    lasers.append([cx, player_y, -1150, 0, TRIPLE_COLOR, piercing_flag, dmg_bonus])
                    lasers.append([cx, player_y, -1100, -160, TRIPLE_COLOR, piercing_flag, dmg_bonus])
                    lasers.append([cx, player_y, -1100, 160, TRIPLE_COLOR, piercing_flag, dmg_bonus])
                else:
                    if w_type == "SCATTER":
                        lasers.append([cx, player_y, -1100, -120, LASER_COLOR, piercing_flag, dmg_bonus])
                        lasers.append([cx, player_y, -1100, 0, LASER_COLOR, piercing_flag, dmg_bonus])
                        lasers.append([cx, player_y, -1100, 120, LASER_COLOR, piercing_flag, dmg_bonus])
                    elif w_type == "PULSE":
                        lasers.append([cx, player_y, -1350, 0, RAPID_COLOR, piercing_flag, dmg_bonus])
                    elif w_type == "BEAM":
                        lasers.append([cx, player_y, -1500, 0, BEAM_COLOR, True, dmg_bonus])
                    else:
                        lasers.append([cx, player_y, -1200, 0, LASER_COLOR, piercing_flag, dmg_bonus])

                s_type = secondary_weapons[secondary_idx]
                if s_type == "HOMING MISSILES" and random.random() < 0.25:
                    missiles.append([cx, player_y, random.uniform(-60, 60), -450])
                elif s_type == "ORBITAL LASER" and random.random() < 0.3:
                    lasers.append([cx - 30, player_y, -1400, 0, OVERCHARGE_COLOR, True, dmg_bonus])
                    lasers.append([cx + 30, player_y, -1400, 0, OVERCHARGE_COLOR, True, dmg_bonus])

                fire_cooldown = base_cd
                heat += 4.0
                if heat >= max_heat:
                    heat = 100.0
                    is_overheated = True
                    overheat_cooldown = 1.2
                    add_floating_text("OVERHEATED!", player_x - 15, player_y - 25, HEALTH_RED)

            if missile_timer > 0:
                missile_timer -= physics_dt
                missile_shoot_timer += physics_dt
                if missile_shoot_timer > 0.28:
                    missiles.append([player_x + player_w // 2, player_y, random.uniform(-60, 60), -450])
                    missile_shoot_timer = 0.0

            for t_name in ['triple_shot_timer', 'rapid_fire_timer', 'shield_timer', 'missile_timer', 
                           'overcharge_timer', 'magnet_timer', 'pierce_timer', 'dash_timer', 'time_slow_timer']:
                if globals()[t_name] > 0:
                    globals()[t_name] -= physics_dt

            if score >= 35 and score % 35 == 0 and boss is None:
                boss = {"x": WIDTH // 2 - 60, "y": 70, "w": 120, "h": 50, "hp": 35, "max_hp": 35, "dir": 1, "speed": 180, "shoot": 0.0}

            enemy_timer += physics_dt
            spawn_rate = max(0.3, 0.65 - (score / 150.0))
            if enemy_timer > spawn_rate and boss is None:
                is_elite = random.random() < 0.22
                if is_elite:
                    enemies.append([random.randint(20, WIDTH - 70), -50, 48, 190.0, 0.5, ELITE_COLOR, 3, True])
                else:
                    enemies.append([random.randint(20, WIDTH - 60), -40, 34, random.uniform(240.0, 350.0), 0.75, ENEMY_COLOR, 1, False])
                enemy_timer = 0.0

            asteroid_timer += physics_dt
            if asteroid_timer > 2.5 and boss is None:
                asteroids.append([random.randint(30, WIDTH - 50), -40, random.randint(22, 36), random.uniform(140.0, 220.0), 2])
                asteroid_timer = 0.0

            coin_timer += physics_dt
            if coin_timer > 0.9:
                coins.append([random.randint(20, WIDTH - 40), -20, 9, 250.0])
                coin_timer = 0.0

            powerup_timer += physics_dt
            if powerup_timer > 3.5:
                ptype = random.choice(["triple", "rapid", "shield", "bomb", "missile", "heal", "magnet", "pierce", "timeslow"])
                powerups.append([random.randint(30, WIDTH - 50), -20, ptype, 210.0])
                powerup_timer = 0.0

            for l in lasers[:]:
                l[1] += l[2] * physics_dt
                l[0] += l[3] * physics_dt
                if l[1] < -20 or l[0] < 0 or l[0] > WIDTH:
                    lasers.remove(l)

            for m in missiles[:]:
                target = None
                if boss:
                    target = (boss["x"] + boss["w"] // 2, boss["y"] + boss["h"] // 2)
                elif enemies:
                    closest = min(enemies, key=lambda e: math.hypot(e[0] - m[0], e[1] - m[1]))
                    target = (closest[0] + closest[2] // 2, closest[1] + closest[2] // 2)

                if target:
                    dx, dy = target[0] - m[0], target[1] - m[1]
                    dist = math.hypot(dx, dy)
                    if dist > 0:
                        m[2] += (dx / dist) * 850.0 * physics_dt
                        m[3] += (dy / dist) * 850.0 * physics_dt
                m[0] += m[2] * physics_dt
                m[1] += m[3] * physics_dt
                if m[1] < -20 or m[1] > HEIGHT + 20:
                    missiles.remove(m)

            for el in enemy_lasers[:]:
                el[1] += el[2] * physics_dt
                if el[1] > HEIGHT:
                    enemy_lasers.remove(el)

            player_rect = pygame.Rect(int(player_x), int(player_y), player_w, player_h)

            if boss:
                boss["x"] += boss["speed"] * boss["dir"] * physics_dt
                if boss["x"] <= 10 or boss["x"] >= WIDTH - boss["w"] - 10:
                    boss["dir"] *= -1
                boss["shoot"] += physics_dt
                if boss["shoot"] > 0.5:
                    enemy_lasers.append([boss["x"] + 20, boss["y"] + boss["h"], 420.0])
                    enemy_lasers.append([boss["x"] + boss["w"] - 20, boss["y"] + boss["h"], 420.0])
                    boss["shoot"] = 0.0
                b_rect = pygame.Rect(int(boss["x"]), int(boss["y"]), int(boss["w"]), int(boss["h"]))
                for l in lasers[:]:
                    if b_rect.colliderect(pygame.Rect(int(l[0]), int(l[1]), 6, 14)):
                        boss["hp"] -= l[6]
                        spawn_particles(l[0], l[1], (255, 200, 100), 3)
                        if not l[5]:
                            if l in lasers: lasers.remove(l)
                        if boss["hp"] <= 0:
                            spawn_particles(boss["x"] + boss["w"]//2, boss["y"] + boss["h"]//2, BOSS_COLOR, 25)
                            mult = max(1, combo_count // 3 + 1)
                            score += 25 * mult
                            bombs += 1
                            boss = None
                            break

            for ast in asteroids[:]:
                ast[1] += ast[3] * physics_dt
                ast_rect = pygame.Rect(int(ast[0] - ast[2]), int(ast[1] - ast[2]), int(ast[2]*2), int(ast[2]*2))
                for l in lasers[:]:
                    if ast_rect.colliderect(pygame.Rect(int(l[0]), int(l[1]), 6, 14)):
                        spawn_particles(l[0], l[1], ASTEROID_COLOR, 3)
                        ast[4] -= l[6]
                        if not l[5]:
                            if l in lasers: lasers.remove(l)
                        if ast[4] <= 0:
                            spawn_particles(ast[0], ast[1], ASTEROID_COLOR, 6)
                            coins.append([ast[0], ast[1], 9, 200.0])
                            score += 2
                            if ast in asteroids: asteroids.remove(ast)
                        break
                if ast_rect.colliderect(player_rect):
                    if ast in asteroids: asteroids.remove(ast)
                    if shield_timer > 0 or dash_timer > 0:
                        pass
                    else:
                        hp -= 1
                        if hp <= 0: game_state = "GAMEOVER"
                elif ast[1] > HEIGHT + 40:
                    if ast in asteroids: asteroids.remove(ast)

            for enemy in enemies[:]:
                enemy[1] += enemy[3] * physics_dt
                enemy[4] -= physics_dt
                if enemy[4] <= 0:
                    enemy_lasers.append([enemy[0] + enemy[2] // 2, enemy[1] + enemy[2], 380.0])
                    if enemy[7]:
                        enemy_lasers.append([enemy[0] + 5, enemy[1] + enemy[2], 340.0])
                        enemy_lasers.append([enemy[0] + enemy[2] - 5, enemy[1] + enemy[2], 340.0])
                    enemy[4] = 999.0
                e_rect = pygame.Rect(int(enemy[0]), int(enemy[1]), int(enemy[2]), int(enemy[2]))
                for l in lasers[:]:
                    if e_rect.colliderect(pygame.Rect(int(l[0]), int(l[1]), 6, 14)):
                        spawn_particles(l[0], l[1], enemy[5], 4)
                        enemy[6] -= l[6]
                        if not l[5]:
                            if l in lasers: lasers.remove(l)
                        if enemy[6] <= 0:
                            spawn_particles(enemy[0] + enemy[2]//2, enemy[1] + enemy[2]//2, enemy[5], 10)
                            combo_count += 1
                            combo_timer = 1.5
                            mult = max(1, combo_count // 3 + 1)
                            score += (3 if enemy[7] else 1) * mult
                            if enemy[7]:
                                powerups.append([enemy[0] + 10, enemy[1], random.choice(["triple", "rapid", "shield", "heal", "magnet", "pierce"]), 190.0])
                            if enemy in enemies: enemies.remove(enemy)
                        break
                if e_rect.colliderect(player_rect):
                    if enemy in enemies: enemies.remove(enemy)
                    if shield_timer > 0 or dash_timer > 0:
                        pass
                    else:
                        hp -= 1
                        if hp <= 0: game_state = "GAMEOVER"
                elif enemy[1] > HEIGHT:
                    if enemy in enemies: enemies.remove(enemy)

            for el in enemy_lasers[:]:
                if player_rect.colliderect(pygame.Rect(int(el[0]), int(el[1]), 6, 12)):
                    enemy_lasers.remove(el)
                    if shield_timer > 0 or dash_timer > 0:
                        pass
                    else:
                        hp -= 1
                        if hp <= 0: game_state = "GAMEOVER"

            for c in coins[:]:
                if magnet_timer > 0:
                    dx, dy = (player_x + player_w // 2) - c[0], (player_y + player_h // 2) - c[1]
                    dist = math.hypot(dx, dy)
                    if dist > 0:
                        c[0] += (dx / dist) * 450.0 * physics_dt
                        c[1] += (dy / dist) * 450.0 * physics_dt
                c[1] += c[3] * physics_dt
                if player_rect.colliderect(pygame.Rect(int(c[0] - c[2]), int(c[1] - c[2]), int(c[2]*2), int(c[2]*2))):
                    coins.remove(c)
                    coins_collected += 1
                    score += 2
                elif c[1] > HEIGHT: coins.remove(c)

            for p in powerups[:]:
                p[1] += p[3] * physics_dt
                if player_rect.colliderect(pygame.Rect(int(p[0] - 16), int(p[1] - 16), 32, 32)):
                    ptype = p[2]
                    if ptype == "triple": triple_shot_timer = 5.0
                    elif ptype == "rapid": rapid_fire_timer = 5.0
                    elif ptype == "shield": shield_timer = 6.0
                    elif ptype == "bomb": bombs += 1
                    elif ptype == "missile": missile_timer = 5.0
                    elif ptype == "heal":
                        hp = min(max_hp, hp + 1)
                        add_floating_text("+1 HP", player_x, player_y - 20, HEAL_COLOR)
                    elif ptype == "magnet":
                        magnet_timer = 7.0
                        add_floating_text("ORB MAGNET!", WIDTH//2 - 60, HEIGHT//2 - 40, MAGNET_COLOR)
                    elif ptype == "pierce":
                        pierce_timer = 6.0
                        add_floating_text("PIERCING LASER!", WIDTH//2 - 75, HEIGHT//2 - 40, PIERCE_COLOR)
                    elif ptype == "timeslow":
                        time_slow_timer = 6.0
                        add_floating_text("TIME SLOW!", WIDTH//2 - 60, HEIGHT//2 - 40, TIME_SLOW_COLOR)
                    powerups.remove(p)
                elif p[1] > HEIGHT: powerups.remove(p)

        for star in stars:
            star[1] += star[2] * physics_dt
            if star[1] > HEIGHT:
                star[1] = 0
                star[0] = random.randint(0, WIDTH)

        for p in particles[:]:
            p[0] += p[2] * physics_dt
            p[1] += p[3] * physics_dt
            p[4] -= physics_dt
            if p[4] <= 0: particles.remove(p)

        for ft in floating_texts[:]:
            ft[2] -= 45.0 * physics_dt
            ft[3] -= physics_dt
            if ft[3] <= 0: floating_texts.remove(ft)

        screen.fill(BG_COLOR)

        for s in stars: pygame.draw.circle(screen, (170, 180, 230), (int(s[0]), int(s[1])), 1)
        for p in particles: pygame.draw.circle(screen, p[5], (int(p[0]), int(p[1])), int(max(1, p[4] * 10)))

        if game_state == "GARAGE":
            title_txt = large_font.render("STARGARAGE", True, WHITE)
            screen.blit(title_txt, (WIDTH // 2 - title_txt.get_width() // 2, 35))

            bank_txt = font.render(f"Orbs Banked: {total_banked_orbs}", True, COIN_COLOR)
            screen.blit(bank_txt, (WIDTH // 2 - bank_txt.get_width() // 2, 75))

            pygame.draw.rect(screen, (40, 40, 70), skin_menu_btn, border_radius=8)
            skin_btn_txt = font.render("SKINS VAULT", True, WHITE)
            screen.blit(skin_btn_txt, (skin_menu_btn.centerx - skin_btn_txt.get_width()//2, skin_menu_btn.centery - skin_btn_txt.get_height()//2))

            pygame.draw.rect(screen, (35, 35, 55), armor_btn, border_radius=8)
            screen.blit(font.render(f"Armor (Lv {armor_level}) - Cost: 5 Orbs", True, WHITE), (armor_btn.x + 15, armor_btn.centery - 10))

            pygame.draw.rect(screen, (35, 35, 55), speed_btn, border_radius=8)
            screen.blit(font.render(f"Thrusters (Lv {speed_level}) - Cost: 5 Orbs", True, WHITE), (speed_btn.x + 15, speed_btn.centery - 10))

            pygame.draw.rect(screen, (35, 35, 55), damage_btn, border_radius=8)
            screen.blit(font.render(f"Laser Damage (Lv {damage_level}) - Cost: 5 Orbs", True, WHITE), (damage_btn.x + 15, damage_btn.centery - 10))

            pygame.draw.rect(screen, (35, 35, 55), primary_wep_btn, border_radius=8)
            screen.blit(font.render(f"Primary Weapon: {primary_weapons[primary_idx]}", True, WHITE), (primary_wep_btn.x + 15, primary_wep_btn.centery - 10))

            pygame.draw.rect(screen, (35, 35, 55), secondary_wep_btn, border_radius=8)
            screen.blit(font.render(f"Secondary Weapon: {secondary_weapons[secondary_idx]}", True, WHITE), (secondary_wep_btn.x + 15, secondary_wep_btn.centery - 10))

            cur_sk = skins[selected_skin_idx]
            prev_x, prev_y = WIDTH // 2, 530
            pygame.draw.polygon(screen, cur_sk["color"] if cur_sk["unlocked"] else (100, 100, 100), [
                (prev_x, prev_y - 25),
                (prev_x - 20, prev_y + 20),
                (prev_x, prev_y + 10),
                (prev_x + 20, prev_y + 20)
            ])

            pygame.draw.rect(screen, (0, 200, 120), launch_btn_rect, border_radius=10)
            launch_txt = large_font.render("LAUNCH", True, WHITE)
            screen.blit(launch_txt, (launch_btn_rect.centerx - launch_txt.get_width()//2, launch_btn_rect.centery - launch_txt.get_height()//2))

        elif game_state == "SKINS":
            t_txt = large_font.render("SKINS VAULT (20)", True, WHITE)
            screen.blit(t_txt, (WIDTH // 2 - t_txt.get_width() // 2, 40))

            b_txt = font.render(f"Orbs: {total_banked_orbs}", True, COIN_COLOR)
            screen.blit(b_txt, (WIDTH // 2 - b_txt.get_width() // 2, 85))

            pygame.draw.rect(screen, (50, 50, 70), back_garage_btn, border_radius=6)
            screen.blit(font.render("< Garage", True, WHITE), (back_garage_btn.centerx - 30, back_garage_btn.centery - 10))

            cur_sk = skins[selected_skin_idx]
            prev_x, prev_y = WIDTH // 2, 280
            pygame.draw.polygon(screen, cur_sk["color"] if cur_sk["unlocked"] else (100, 100, 100), [
                (prev_x, prev_y - 40),
                (prev_x - 35, prev_y + 35),
                (prev_x, prev_y + 15),
                (prev_x + 35, prev_y + 35)
            ])

            s_name = large_font.render(cur_sk["name"], True, cur_sk["color"] if cur_sk["unlocked"] else WHITE)
            screen.blit(s_name, (WIDTH // 2 - s_name.get_width() // 2, 370))

            status_str = "UNLOCKED" if cur_sk["unlocked"] else f"COST: {cur_sk['cost']} ORBS"
            s_stat = font.render(status_str, True, COIN_COLOR if not cur_sk["unlocked"] else HEALTH_GREEN)
            screen.blit(s_stat, (WIDTH // 2 - s_stat.get_width() // 2, 420))

            pygame.draw.rect(screen, (40, 40, 60), skin_prev_btn, border_radius=8)
            pygame.draw.rect(screen, (40, 40, 60), skin_next_btn, border_radius=8)
            screen.blit(large_font.render("<", True, WHITE), (skin_prev_btn.centerx - 8, skin_prev_btn.centery - 15))
            screen.blit(large_font.render(">", True, WHITE), (skin_next_btn.centerx - 8, skin_next_btn.centery - 15))

            if not cur_sk["unlocked"]:
                pygame.draw.rect(screen, (200, 140, 0), skin_buy_btn, border_radius=8)
                buy_txt = large_font.render("BUY SKIN", True, WHITE)
                screen.blit(buy_txt, (skin_buy_btn.centerx - buy_txt.get_width()//2, skin_buy_btn.centery - buy_txt.get_height()//2))

        elif game_state == "PLAYING":
            for l in lasers: pygame.draw.rect(screen, l[4], (int(l[0]), int(l[1]), 5, 16), border_radius=2)
            for m in missiles: pygame.draw.circle(screen, MISSILE_COLOR, (int(m[0]), int(m[1])), 4)
            for el in enemy_lasers: pygame.draw.rect(screen, ENEMY_LASER_COLOR, (int(el[0]), int(el[1]), 6, 14), border_radius=2)

            if shield_timer > 0 or dash_timer > 0:
                pygame.draw.circle(screen, SHIELD_COLOR, (int(player_x + player_w // 2), int(player_y + player_h // 2)), int(player_w * 0.8), 2)
            
            cur_skin_color = skins[selected_skin_idx]["color"]
            p_col = OVERCHARGE_COLOR if overcharge_timer > 0 else (TRIPLE_COLOR if triple_shot_timer > 0 else (RAPID_COLOR if rapid_fire_timer > 0 else cur_skin_color))
            
            px_int = int(player_x)
            py_int = int(player_y)
            pygame.draw.polygon(screen, p_col, [
                (px_int + player_w // 2, py_int),
                (px_int + 6, py_int + player_h - 6),
                (px_int + player_w // 2, py_int + player_h - 14),
                (px_int + player_w - 6, py_int + player_h - 6)
            ])
            pygame.draw.polygon(screen, WHITE, [
                (px_int + player_w // 2, py_int + 10),
                (px_int + player_w // 2 - 4, py_int + player_h - 18),
                (px_int + player_w // 2 + 4, py_int + player_h - 18)
            ])

            if boss:
                pygame.draw.rect(screen, BOSS_COLOR, (int(boss["x"]), int(boss["y"]), int(boss["w"]), int(boss["h"])), border_radius=6)
                pygame.draw.polygon(screen, (255, 100, 100), [
                    (int(boss["x"] + boss["w"] // 2), int(boss["y"] - 15)),
                    (int(boss["x"] + 10), int(boss["y"])),
                    (int(boss["x"] + boss["w"] - 10), int(boss["y"]))
                ])
                pygame.draw.rect(screen, HEALTH_GREEN, (int(boss["x"]), int(boss["y"] - 22), int(boss["w"] * (boss["hp"] / boss["max_hp"])), 6))

            for ast in asteroids:
                pygame.draw.circle(screen, ASTEROID_COLOR, (int(ast[0]), int(ast[1])), int(ast[2]))

            for e in enemies:
                ex, ey = int(e[0]), int(e[1])
                ew = int(e[2])
                pygame.draw.polygon(screen, e[5], [
                    (ex + ew//2, ey + ew if not e[7] else ey),
                    (ex, ey + (0 if e[7] else ew)),
                    (ex + ew, ey + (0 if e[7] else ew))
                ])

            for c in coins: pygame.draw.circle(screen, COIN_COLOR, (int(c[0]), int(c[1])), int(c[2]))
            for pu in powerups:
                pygame.draw.circle(screen, WHITE, (int(pu[0]), int(pu[1])), 12)

            fire_btn_col = HEALTH_RED if is_overheated else (0, 200, 255)
            pygame.draw.circle(screen, (30, 30, 45), (fire_btn_rect.centerx, fire_btn_rect.centery), fire_btn_rect.width // 2)
            pygame.draw.circle(screen, fire_btn_col, (fire_btn_rect.centerx, fire_btn_rect.centery), fire_btn_rect.width // 2 - 2, 2)
            f_txt = font.render("FIRE", True, fire_btn_col)
            screen.blit(f_txt, (fire_btn_rect.centerx - f_txt.get_width() // 2, fire_btn_rect.centery - f_txt.get_height() // 2))

            pygame.draw.circle(screen, (35, 35, 50), (bomb_btn_rect.centerx, bomb_btn_rect.centery), bomb_btn_rect.width // 2)
            pygame.draw.circle(screen, BOMB_COLOR, (bomb_btn_rect.centerx, bomb_btn_rect.centery), bomb_btn_rect.width // 2 - 2, 2)
            b_txt = font.render(f"NUKE:{bombs}", True, BOMB_COLOR)
            screen.blit(b_txt, (bomb_btn_rect.centerx - b_txt.get_width() // 2, bomb_btn_rect.centery - b_txt.get_height() // 2))

            pygame.draw.circle(screen, (35, 35, 50), (dash_btn_rect.centerx, dash_btn_rect.centery), dash_btn_rect.width // 2)
            pygame.draw.circle(screen, DASH_COLOR, (dash_btn_rect.centerx, dash_btn_rect.centery), dash_btn_rect.width // 2 - 2, 2)
            d_txt = font.render("DASH", True, DASH_COLOR)
            screen.blit(d_txt, (dash_btn_rect.centerx - d_txt.get_width() // 2, dash_btn_rect.centery - d_txt.get_height() // 2))

            screen.blit(font.render(f"Score: {score}", True, WHITE), (15, 15))
            screen.blit(font.render(f"Orbs: {coins_collected}", True, COIN_COLOR), (15, 38))

            for ft in floating_texts:
                screen.blit(font.render(ft[0], True, ft[4]), (int(ft[1]), int(ft[2])))

            pygame.draw.rect(screen, HEALTH_RED, (WIDTH - 140, 20, 120, 12), border_radius=3)
            pygame.draw.rect(screen, HEALTH_GREEN, (WIDTH - 140, 20, int(120 * (hp / max_hp)), 12), border_radius=3)

        elif game_state == "GAMEOVER":
            over_text = large_font.render("MISSION FAILED", True, ENEMY_COLOR)
            screen.blit(over_text, (WIDTH // 2 - over_text.get_width() // 2, HEIGHT // 3))
            
            score_final = font.render(f"Final Score: {score} | Orbs: {coins_collected}", True, WHITE)
            screen.blit(score_final, (WIDTH // 2 - score_final.get_width() // 2, HEIGHT // 3 + 55))

            pygame.draw.rect(screen, (0, 180, 120), restart_btn_rect, border_radius=8)
            r_txt = font.render("MAIN MENU", True, WHITE)
            screen.blit(r_txt, (restart_btn_rect.centerx - r_txt.get_width() // 2, restart_btn_rect.centery - r_txt.get_height() // 2))

        pygame.display.flip()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())