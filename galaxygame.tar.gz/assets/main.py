import pygame
import random
import math
import asyncio
import sys

pygame.init()
pygame.font.init()

WIDTH, HEIGHT = 450, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Galaxy Striker")
clock = pygame.time.Clock()

BG_COLOR = (8, 8, 24)
PLAYER_COLOR = (0, 220, 255)
LASER_COLOR = (0, 255, 180)
BEAM_COLOR = (0, 255, 255)
ENEMY_COLOR = (255, 60, 90)
ELITE_COLOR = (200, 50, 255)
ENEMY_LASER_COLOR = (255, 120, 30)
BOSS_COLOR = (255, 30, 30)
COIN_COLOR = (255, 215, 0)
ASTEROID_COLOR = (140, 140, 160)
TRIPLE_COLOR = (180, 70, 255)
RAPID_COLOR = (0, 255, 255)
SHIELD_COLOR = (255, 200, 50)
BOMB_COLOR = (255, 80, 0)
DASH_COLOR = (0, 255, 180)
MISSILE_COLOR = (50, 255, 120)
HEAL_COLOR = (50, 255, 100)
MAGNET_COLOR = (255, 100, 255)
PIERCE_COLOR = (100, 200, 255)
OVERCHARGE_COLOR = (0, 255, 255)
TIME_SLOW_COLOR = (100, 255, 255)
WHITE = (255, 255, 255)
HEALTH_GREEN = (50, 220, 90)
HEALTH_RED = (200, 40, 40)

font = pygame.font.Font(None, 24)
large_font = pygame.font.Font(None, 40)

class Game:
    def __init__(self):
        self.player_w = 44
        self.player_h = 44
        self.player_x = float(WIDTH // 2 - self.player_w // 2)
        self.player_y = float(HEIGHT - self.player_h - 130)

        self.total_banked_orbs = 50

        self.skins = [
            {"name": "Default Viper", "color": (0, 220, 255), "cost": 0, "unlocked": True},
            {"name": "Crimson Hawk", "color": (255, 50, 50), "cost": 10, "unlocked": False},
            {"name": "Gold Sentinel", "color": (255, 215, 0), "cost": 25, "unlocked": False},
            {"name": "Neon Phantom", "color": (200, 50, 255), "cost": 40, "unlocked": False},
            {"name": "Emerald Stalker", "color": (50, 255, 100), "cost": 60, "unlocked": False},
            {"name": "Solar Flare", "color": (255, 140, 0), "cost": 80, "unlocked": False},
            {"name": "Void Reaver", "color": (100, 100, 120), "cost": 100, "unlocked": False},
            {"name": "Cyber Ghost", "color": (0, 255, 200), "cost": 120, "unlocked": False},
            {"name": "Ruby Corsair", "color": (220, 20, 60), "cost": 150, "unlocked": False},
            {"name": "Sapphire Knight", "color": (30, 144, 255), "cost": 180, "unlocked": False},
            {"name": "Amethyst Lord", "color": (153, 50, 204), "cost": 210, "unlocked": False},
            {"name": "Titanium Core", "color": (192, 192, 192), "cost": 250, "unlocked": False},
            {"name": "Plasma Beast", "color": (255, 0, 255), "cost": 300, "unlocked": False},
            {"name": "Acid Viper", "color": (124, 252, 0), "cost": 350, "unlocked": False},
            {"name": "Frostbite", "color": (175, 238, 238), "cost": 400, "unlocked": False},
            {"name": "Magma Striker", "color": (255, 69, 0), "cost": 450, "unlocked": False},
            {"name": "Shadow Fiend", "color": (75, 0, 130), "cost": 500, "unlocked": False},
            {"name": "Supernova", "color": (255, 255, 255), "cost": 600, "unlocked": False},
            {"name": "Quantum Glitch", "color": (0, 255, 127), "cost": 750, "unlocked": False},
            {"name": "Galaxy Emperor", "color": (255, 215, 0), "cost": 1000, "unlocked": False}
        ]
        self.selected_skin_idx = 0

        self.armor_level = 1
        self.speed_level = 1
        self.damage_level = 1

        self.primary_weapons = ["PLASMA", "PULSE", "SCATTER", "BEAM"]
        self.primary_idx = 0
        self.secondary_weapons = ["NONE", "HOMING MISSILES", "EMP MINES", "ORBITAL LASER"]
        self.secondary_idx = 0

        self.game_state = "GARAGE"
        self.reset_session()

        self.stars = [[random.randint(0, WIDTH), random.randint(0, HEIGHT), random.randint(140, 300)] for _ in range(45)]
        
        self.fire_btn_rect = pygame.Rect(WIDTH - 85, HEIGHT - 105, 75, 75)
        self.bomb_btn_rect = pygame.Rect(WIDTH - 170, HEIGHT - 105, 75, 75)
        self.dash_btn_rect = pygame.Rect(WIDTH - 255, HEIGHT - 105, 75, 75)

        self.skin_menu_btn = pygame.Rect(40, 150, 370, 45)
        self.armor_btn = pygame.Rect(40, 210, 370, 40)
        self.speed_btn = pygame.Rect(40, 260, 370, 40)
        self.damage_btn = pygame.Rect(40, 310, 370, 40)
        self.primary_wep_btn = pygame.Rect(40, 370, 370, 40)
        self.secondary_wep_btn = pygame.Rect(40, 420, 370, 40)
        self.launch_btn_rect = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 120, 220, 50)

        self.back_garage_btn = pygame.Rect(40, 40, 120, 40)
        self.skin_prev_btn = pygame.Rect(40, HEIGHT // 2 - 30, 60, 60)
        self.skin_next_btn = pygame.Rect(WIDTH - 100, HEIGHT // 2 - 30, 60, 60)
        self.skin_buy_btn = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 150, 220, 50)

        self.restart_btn_rect = pygame.Rect(WIDTH // 2 - 120, HEIGHT // 2 + 60, 240, 55)
        self.active_touches = {}

    def reset_session(self):
        self.max_hp = 4 + self.armor_level
        self.hp = self.max_hp
        self.player_x = float(WIDTH // 2 - self.player_w // 2)
        self.bombs = 2
        self.dash_charges = 2

        self.heat = 0.0
        self.max_heat = 100.0
        self.is_overheated = False
        self.overheat_cooldown = 0.0
        self.fire_cooldown = 0.0

        self.triple_shot_timer = 0.0
        self.rapid_fire_timer = 0.0
        self.shield_timer = 0.0
        self.missile_timer = 0.0
        self.missile_shoot_timer = 0.0
        self.overcharge_timer = 0.0
        self.magnet_timer = 0.0
        self.pierce_timer = 0.0
        self.dash_timer = 0.0
        self.time_slow_timer = 0.0

        self.combo_count = 0
        self.combo_timer = 0.0

        self.lasers = []
        self.missiles = []
        self.enemy_lasers = []
        self.enemies = []
        self.asteroids = []
        self.coins = []
        self.powerups = []
        self.particles = []
        self.floating_texts = []
        self.boss = None

        self.score = 0
        self.coins_collected = 0
        self.enemy_timer = 0.0
        self.asteroid_timer = 0.0
        self.coin_timer = 0.0
        self.powerup_timer = 0.0

    def spawn_particles(self, x, y, color, count=6):
        for _ in range(count):
            self.particles.append([x, y, random.uniform(-180, 180), random.uniform(-180, 180), random.uniform(0.2, 0.45), color])

    def add_floating_text(self, text, x, y, color):
        self.floating_texts.append([text, x, y, 0.6, color])

    def trigger_nuke(self):
        if self.bombs > 0:
            self.bombs -= 1
            self.add_floating_text("MEGA NUKE!", WIDTH // 2 - 60, HEIGHT // 2, BOMB_COLOR)
            for e in self.enemies:
                self.spawn_particles(e[0] + e[2]//2, e[1] + e[2]//2, e[5], 8)
                self.score += 1
            self.enemies.clear()
            self.asteroids.clear()
            self.enemy_lasers.clear()
            if self.boss:
                self.boss["hp"] -= 20

    def trigger_dash(self):
        if self.dash_charges > 0:
            self.dash_charges -= 1
            self.dash_timer = 0.35
            self.add_floating_text("DASH!", WIDTH // 2 - 30, HEIGHT // 2, DASH_COLOR)

async def main():
    g = Game()
    last_time = pygame.time.get_ticks()

    running = True
    while running:
        current_time = pygame.time.get_ticks()
        dt = (current_time - last_time) / 1000.0
        last_time = current_time
        dt = min(dt, 0.05)
        physics_dt = dt * 0.5 if g.time_slow_timer > 0 else dt

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                if event.type == pygame.FINGERDOWN:
                    pos = (int(event.x * WIDTH), int(event.y * HEIGHT))
                    tid = event.finger_id
                else:
                    pos = pygame.mouse.get_pos()
                    tid = 'mouse'

                g.active_touches[tid] = pos

                if g.game_state == "GARAGE":
                    if g.skin_menu_btn.collidepoint(pos):
                        g.game_state = "SKINS"
                    elif g.armor_btn.collidepoint(pos) and g.total_banked_orbs >= 5:
                        g.total_banked_orbs -= 5
                        g.armor_level += 1
                    elif g.speed_btn.collidepoint(pos) and g.total_banked_orbs >= 5:
                        g.total_banked_orbs -= 5
                        g.speed_level += 1
                    elif g.damage_btn.collidepoint(pos) and g.total_banked_orbs >= 5:
                        g.total_banked_orbs -= 5
                        g.damage_level += 1
                    elif g.primary_wep_btn.collidepoint(pos):
                        g.primary_idx = (g.primary_idx + 1) % len(g.primary_weapons)
                    elif g.secondary_wep_btn.collidepoint(pos):
                        g.secondary_idx = (g.secondary_idx + 1) % len(g.secondary_weapons)
                    elif g.launch_btn_rect.collidepoint(pos):
                        g.reset_session()
                        g.active_touches.clear()
                        last_time = pygame.time.get_ticks()
                        g.game_state = "PLAYING"
                elif g.game_state == "SKINS":
                    if g.back_garage_btn.collidepoint(pos):
                        g.game_state = "GARAGE"
                    elif g.skin_prev_btn.collidepoint(pos):
                        g.selected_skin_idx = (g.selected_skin_idx - 1) % len(g.skins)
                    elif g.skin_next_btn.collidepoint(pos):
                        g.selected_skin_idx = (g.selected_skin_idx + 1) % len(g.skins)
                    elif g.skin_buy_btn.collidepoint(pos):
                        sk = g.skins[g.selected_skin_idx]
                        if not sk["unlocked"] and g.total_banked_orbs >= sk["cost"]:
                            g.total_banked_orbs -= sk["cost"]
                            sk["unlocked"] = True
                elif g.game_state == "GAMEOVER":
                    if g.restart_btn_rect.collidepoint(pos):
                        g.total_banked_orbs += g.coins_collected
                        g.game_state = "GARAGE"
                elif g.game_state == "PLAYING":
                    if g.bomb_btn_rect.collidepoint(pos):
                        g.trigger_nuke()
                    elif g.dash_btn_rect.collidepoint(pos):
                        g.trigger_dash()

            elif event.type == pygame.FINGERMOTION:
                g.active_touches[event.finger_id] = (int(event.x * WIDTH), int(event.y * HEIGHT))
            elif event.type == pygame.MOUSEMOTION:
                if 'mouse' in g.active_touches:
                    g.active_touches['mouse'] = pygame.mouse.get_pos()
            elif event.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP):
                tid = event.finger_id if event.type == pygame.FINGERUP else 'mouse'
                if tid in g.active_touches:
                    del g.active_touches[tid]

        if g.game_state == "PLAYING":
            is_touching_fire = False
            is_moving = False
            move_target_x = g.player_x

            for tid, pos in g.active_touches.items():
                if g.fire_btn_rect.collidepoint(pos):
                    is_touching_fire = True
                elif g.bomb_btn_rect.collidepoint(pos) or g.dash_btn_rect.collidepoint(pos):
                    pass
                else:
                    is_moving = True
                    move_target_x = pos[0] - g.player_w // 2

            if is_moving:
                base_spd = 28.0 + (g.speed_level * 4.0)
                current_speed = base_spd * (2.2 if g.dash_timer > 0 else 1.0)
                g.player_x += (move_target_x - g.player_x) * min(1.0, current_speed * physics_dt)
                g.player_x = max(0.0, min(float(WIDTH - g.player_w), g.player_x))

            if g.combo_timer > 0:
                g.combo_timer -= physics_dt
            else:
                g.combo_count = 0

            if g.is_overheated:
                g.overheat_cooldown -= physics_dt
                g.heat = (g.overheat_cooldown / 1.2) * 100.0
                if g.overheat_cooldown <= 0:
                    g.is_overheated = False
                    g.heat = 0.0
            else:
                if not is_touching_fire and g.heat > 0:
                    g.heat = max(0.0, g.heat - 55.0 * physics_dt)

            base_cd = 0.06 if g.rapid_fire_timer > 0 else 0.12
            if g.fire_cooldown > 0:
                g.fire_cooldown -= physics_dt

            if is_touching_fire and not g.is_overheated and g.fire_cooldown <= 0:
                cx = g.player_x + g.player_w // 2 - 2
                piercing_flag = (g.pierce_timer > 0)
                w_type = g.primary_weapons[g.primary_idx]
                dmg_bonus = g.damage_level

                if g.triple_shot_timer > 0:
                    g.lasers.append([cx, g.player_y, -1150, 0, TRIPLE_COLOR, piercing_flag, dmg_bonus])
                    g.lasers.append([cx, g.player_y, -1100, -160, TRIPLE_COLOR, piercing_flag, dmg_bonus])
                    g.lasers.append([cx, g.player_y, -1100, 160, TRIPLE_COLOR, piercing_flag, dmg_bonus])
                else:
                    if w_type == "SCATTER":
                        g.lasers.append([cx, g.player_y, -1100, -120, LASER_COLOR, piercing_flag, dmg_bonus])
                        g.lasers.append([cx, g.player_y, -1100, 0, LASER_COLOR, piercing_flag, dmg_bonus])
                        g.lasers.append([cx, g.player_y, -1100, 120, LASER_COLOR, piercing_flag, dmg_bonus])
                    elif w_type == "PULSE":
                        g.lasers.append([cx, g.player_y, -1350, 0, RAPID_COLOR, piercing_flag, dmg_bonus])
                    elif w_type == "BEAM":
                        g.lasers.append([cx, g.player_y, -1500, 0, BEAM_COLOR, True, dmg_bonus])
                    else:
                        g.lasers.append([cx, g.player_y, -1200, 0, LASER_COLOR, piercing_flag, dmg_bonus])

                s_type = g.secondary_weapons[g.secondary_idx]
                if s_type == "HOMING MISSILES" and random.random() < 0.25:
                    g.missiles.append([cx, g.player_y, random.uniform(-60, 60), -450])
                elif s_type == "ORBITAL LASER" and random.random() < 0.3:
                    g.lasers.append([cx - 30, g.player_y, -1400, 0, OVERCHARGE_COLOR, True, dmg_bonus])
                    g.lasers.append([cx + 30, g.player_y, -1400, 0, OVERCHARGE_COLOR, True, dmg_bonus])

                g.fire_cooldown = base_cd
                g.heat += 4.0
                if g.heat >= g.max_heat:
                    g.heat = 100.0
                    g.is_overheated = True
                    g.overheat_cooldown = 1.2
                    g.add_floating_text("OVERHEATED!", g.player_x - 15, g.player_y - 25, HEALTH_RED)

            if g.missile_timer > 0:
                g.missile_timer -= physics_dt
                g.missile_shoot_timer += physics_dt
                if g.missile_shoot_timer > 0.28:
                    g.missiles.append([g.player_x + g.player_w // 2, g.player_y, random.uniform(-60, 60), -450])
                    g.missile_shoot_timer = 0.0

            # Countdown timers directly
            if g.triple_shot_timer > 0: g.triple_shot_timer -= physics_dt
            if g.rapid_fire_timer > 0: g.rapid_fire_timer -= physics_dt
            if g.shield_timer > 0: g.shield_timer -= physics_dt
            if g.missile_timer > 0: g.missile_timer -= physics_dt
            if g.overcharge_timer > 0: g.overcharge_timer -= physics_dt
            if g.magnet_timer > 0: g.magnet_timer -= physics_dt
            if g.pierce_timer > 0: g.pierce_timer -= physics_dt
            if g.dash_timer > 0: g.dash_timer -= physics_dt
            if g.time_slow_timer > 0: g.time_slow_timer -= physics_dt

            if g.score >= 35 and g.score % 35 == 0 and g.boss is None:
                g.boss = {"x": WIDTH // 2 - 60, "y": 70, "w": 120, "h": 50, "hp": 35, "max_hp": 35, "dir": 1, "speed": 180, "shoot": 0.0}

            g.enemy_timer += physics_dt
            spawn_rate = max(0.3, 0.65 - (g.score / 150.0))
            if g.enemy_timer > spawn_rate and g.boss is None:
                is_elite = random.random() < 0.22
                if is_elite:
                    g.enemies.append([random.randint(20, WIDTH - 70), -50, 48, 190.0, 0.5, ELITE_COLOR, 3, True])
                else:
                    g.enemies.append([random.randint(20, WIDTH - 60), -40, 34, random.uniform(240.0, 350.0), 0.75, ENEMY_COLOR, 1, False])
                g.enemy_timer = 0.0

            g.asteroid_timer += physics_dt
            if g.asteroid_timer > 2.5 and g.boss is None:
                g.asteroids.append([random.randint(30, WIDTH - 50), -40, random.randint(22, 36), random.uniform(140.0, 220.0), 2])
                g.asteroid_timer = 0.0

            g.coin_timer += physics_dt
            if g.coin_timer > 0.9:
                g.coins.append([random.randint(20, WIDTH - 40), -20, 9, 250.0])
                g.coin_timer = 0.0

            g.powerup_timer += physics_dt
            if g.powerup_timer > 3.5:
                ptype = random.choice(["triple", "rapid", "shield", "bomb", "missile", "heal", "magnet", "pierce", "timeslow"])
                g.powerups.append([random.randint(30, WIDTH - 50), -20, ptype, 210.0])
                g.powerup_timer = 0.0

            for l in g.lasers[:]:
                l[1] += l[2] * physics_dt
                l[0] += l[3] * physics_dt
                if l[1] < -20 or l[0] < 0 or l[0] > WIDTH:
                    g.lasers.remove(l)

            for m in g.missiles[:]:
                target = None
                if g.boss:
                    target = (g.boss["x"] + g.boss["w"] // 2, g.boss["y"] + g.boss["h"] // 2)
                elif g.enemies:
                    closest = min(g.enemies, key=lambda e: math.hypot(e[0] - m[0], e[1] - m[1]))
                    target = (closest[0] + closest[2] // 2, closest[1] + closest[2] // 2)

                if target:
                    dx, dy = target[0] - m[0], target[1] - m[1]
                    dist = math.hypot(dx, dy)
                    if dist > 0:
                        m[2] += (dx / dist) * 850.0 * physics_dt
                        m[3] += (dy / dist) * 850.0 * physics_dt
                m[0] += m[2] * physics_dt
                m[1] += m[3] * physics_dt
                if m[1] < -20 or m[1] > HEIGHT + 20:
                    g.missiles.remove(m)

            for el in g.enemy_lasers[:]:
                el[1] += el[2] * physics_dt
                if el[1] > HEIGHT:
                    g.enemy_lasers.remove(el)

            player_rect = pygame.Rect(int(g.player_x), int(g.player_y), g.player_w, g.player_h)

            if g.boss:
                g.boss["x"] += g.boss["speed"] * g.boss["dir"] * physics_dt
                if g.boss["x"] <= 10 or g.boss["x"] >= WIDTH - g.boss["w"] - 10:
                    g.boss["dir"] *= -1
                g.boss["shoot"] += physics_dt
                if g.boss["shoot"] > 0.5:
                    g.enemy_lasers.append([g.boss["x"] + 20, g.boss["y"] + g.boss["h"], 420.0])
                    g.enemy_lasers.append([g.boss["x"] + g.boss["w"] - 20, g.boss["y"] + g.boss["h"], 420.0])
                    g.boss["shoot"] = 0.0
                b_rect = pygame.Rect(int(g.boss["x"]), int(g.boss["y"]), int(g.boss["w"]), int(g.boss["h"]))
                for l in g.lasers[:]:
                    if b_rect.colliderect(pygame.Rect(int(l[0]), int(l[1]), 6, 14)):
                        g.boss["hp"] -= l[6]
                        g.spawn_particles(l[0], l[1], (255, 200, 100), 3)
                        if not l[5]:
                            if l in g.lasers: g.lasers.remove(l)
                        if g.boss["hp"] <= 0:
                            g.spawn_particles(g.boss["x"] + g.boss["w"]//2, g.boss["y"] + g.boss["h"]//2, BOSS_COLOR, 25)
                            mult = max(1, g.combo_count // 3 + 1)
                            g.score += 25 * mult
                            g.bombs += 1
                            g.boss = None
                            break

            for ast in g.asteroids[:]:
                ast[1] += ast[3] * physics_dt
                ast_rect = pygame.Rect(int(ast[0] - ast[2]), int(ast[1] - ast[2]), int(ast[2]*2), int(ast[2]*2))
                for l in g.lasers[:]:
                    if ast_rect.colliderect(pygame.Rect(int(l[0]), int(l[1]), 6, 14)):
                        g.spawn_particles(l[0], l[1], ASTEROID_COLOR, 3)
                        ast[4] -= l[6]
                        if not l[5]:
                            if l in g.lasers: g.lasers.remove(l)
                        if ast[4] <= 0:
                            g.spawn_particles(ast[0], ast[1], ASTEROID_COLOR, 6)
                            g.coins.append([ast[0], ast[1], 9, 200.0])
                            g.score += 2
                            if ast in g.asteroids: g.asteroids.remove(ast)
                        break
                if ast_rect.colliderect(player_rect):
                    if ast in g.asteroids: g.asteroids.remove(ast)
                    if g.shield_timer > 0 or g.dash_timer > 0:
                        pass
                    else:
                        g.hp -= 1
                        if g.hp <= 0: g.game_state = "GAMEOVER"
                elif ast[1] > HEIGHT + 40:
                    if ast in g.asteroids: g.asteroids.remove(ast)

            for enemy in g.enemies[:]:
                enemy[1] += enemy[3] * physics_dt
                enemy[4] -= physics_dt
                if enemy[4] <= 0:
                    g.enemy_lasers.append([enemy[0] + enemy[2] // 2, enemy[1] + enemy[2], 380.0])
                    if enemy[7]:
                        g.enemy_lasers.append([enemy[0] + 5, enemy[1] + enemy[2], 340.0])
                        g.enemy_lasers.append([enemy[0] + enemy[2] - 5, enemy[1] + enemy[2], 340.0])
                    enemy[4] = 999.0
                e_rect = pygame.Rect(int(enemy[0]), int(enemy[1]), int(enemy[2]), int(enemy[2]))
                for l in g.lasers[:]:
                    if e_rect.colliderect(pygame.Rect(int(l[0]), int(l[1]), 6, 14)):
                        g.spawn_particles(l[0], l[1], enemy[5], 4)
                        enemy[6] -= l[6]
                        if not l[5]:
                            if l in g.lasers: g.lasers.remove(l)
                        if enemy[6] <= 0:
                            g.spawn_particles(enemy[0] + enemy[2]//2, enemy[1] + enemy[2]//2, enemy[5], 10)
                            g.combo_count += 1
                            g.combo_timer = 1.5
                            mult = max(1, g.combo_count // 3 + 1)
                            g.score += (3 if enemy[7] else 1) * mult
                            if enemy[7]:
                                g.powerups.append([enemy[0] + 10, enemy[1], random.choice(["triple", "rapid", "shield", "heal", "magnet", "pierce"]), 190.0])
                            if enemy in g.enemies: g.enemies.remove(enemy)
                        break
                if e_rect.colliderect(player_rect):
                    if enemy in g.enemies: g.enemies.remove(enemy)
                    if g.shield_timer > 0 or g.dash_timer > 0:
                        pass
                    else:
                        g.hp -= 1
                        if g.hp <= 0: g.game_state = "GAMEOVER"
                elif enemy[1] > HEIGHT:
                    if enemy in g.enemies: g.enemies.remove(enemy)

            for el in g.enemy_lasers[:]:
                if player_rect.colliderect(pygame.Rect(int(el[0]), int(el[1]), 6, 12)):
                    g.enemy_lasers.remove(el)
                    if g.shield_timer > 0 or g.dash_timer > 0:
                        pass
                    else:
                        g.hp -= 1
                        if g.hp <= 0: g.game_state = "GAMEOVER"

            for c in g.coins[:]:
                if g.magnet_timer > 0:
                    dx, dy = (g.player_x + g.player_w // 2) - c[0], (g.player_y + g.player_h // 2) - c[1]
                    dist = math.hypot(dx, dy)
                    if dist > 0:
                        c[0] += (dx / dist) * 450.0 * physics_dt
                        c[1] += (dy / dist) * 450.0 * physics_dt
                c[1] += c[3] * physics_dt
                if player_rect.colliderect(pygame.Rect(int(c[0] - c[2]), int(c[1] - c[2]), int(c[2]*2), int(c[2]*2))):
                    g.coins.remove(c)
                    g.coins_collected += 1
                    g.score += 2
                elif c[1] > HEIGHT: g.coins.remove(c)

            for p in g.powerups[:]:
                p[1] += p[3] * physics_dt
                if player_rect.colliderect(pygame.Rect(int(p[0] - 16), int(p[1] - 16), 32, 32)):
                    ptype = p[2]
                    if ptype == "triple": g.triple_shot_timer = 5.0
                    elif ptype == "rapid": g.rapid_fire_timer = 5.0
                    elif ptype == "shield": g.shield_timer = 6.0
                    elif ptype == "bomb": g.bombs += 1
                    elif ptype == "missile": g.missile_timer = 5.0
                    elif ptype == "heal":
                        g.hp = min(g.max_hp, g.hp + 1)
                        g.add_floating_text("+1 HP", g.player_x, g.player_y - 20, HEAL_COLOR)
                    elif ptype == "magnet":
                        g.magnet_timer = 7.0
                        g.add_floating_text("ORB MAGNET!", WIDTH//2 - 60, HEIGHT//2 - 40, MAGNET_COLOR)
                    elif ptype == "pierce":
                        g.pierce_timer = 6.0
                        g.add_floating_text("PIERCING LASER!", WIDTH//2 - 75, HEIGHT//2 - 40, PIERCE_COLOR)
                    elif ptype == "timeslow":
                        g.time_slow_timer = 6.0
                        g.add_floating_text("TIME SLOW!", WIDTH//2 - 60, HEIGHT//2 - 40, TIME_SLOW_COLOR)
                    g.powerups.remove(p)
                elif p[1] > HEIGHT: g.powerups.remove(p)

        for star in g.stars:
            star[1] += star[2] * physics_dt
            if star[1] > HEIGHT:
                star[1] = 0
                star[0] = random.randint(0, WIDTH)

        for p in g.particles[:]:
            p[0] += p[2] * physics_dt
            p[1] += p[3] * physics_dt
            p[4] -= physics_dt
            if p[4] <= 0: g.particles.remove(p)

        for ft in g.floating_texts[:]:
            ft[2] -= 45.0 * physics_dt
            ft[3] -= physics_dt
            if ft[3] <= 0: g.floating_texts.remove(ft)

        screen.fill(BG_COLOR)

        for s in g.stars: pygame.draw.circle(screen, (170, 180, 230), (int(s[0]), int(s[1])), 1)
        for p in g.particles: pygame.draw.circle(screen, p[5], (int(p[0]), int(p[1])), int(max(1, p[4] * 10)))

        if g.game_state == "GARAGE":
            title_txt = large_font.render("STARGARAGE", True, WHITE)
            screen.blit(title_txt, (WIDTH // 2 - title_txt.get_width() // 2, 35))

            bank_txt = font.render(f"Orbs Banked: {g.total_banked_orbs}", True, COIN_COLOR)
            screen.blit(bank_txt, (WIDTH // 2 - bank_txt.get_width() // 2, 75))

            pygame.draw.rect(screen, (40, 40, 70), g.skin_menu_btn, border_radius=8)
            skin_btn_txt = font.render("SKINS VAULT", True, WHITE)
            screen.blit(skin_btn_txt, (g.skin_menu_btn.centerx - skin_btn_txt.get_width()//2, g.skin_menu_btn.centery - skin_btn_txt.get_height()//2))

            pygame.draw.rect(screen, (35, 35, 55), g.armor_btn, border_radius=8)
            screen.blit(font.render(f"Armor (Lv {g.armor_level}) - Cost: 5 Orbs", True, WHITE), (g.armor_btn.x + 15, g.armor_btn.centery - 10))

            pygame.draw.rect(screen, (35, 35, 55), g.speed_btn, border_radius=8)
            screen.blit(font.render(f"Thrusters (Lv {g.speed_level}) - Cost: 5 Orbs", True, WHITE), (g.speed_btn.x + 15, g.speed_btn.centery - 10))

            pygame.draw.rect(screen, (35, 35, 55), g.damage_btn, border_radius=8)
            screen.blit(font.render(f"Laser Damage (Lv {g.damage_level}) - Cost: 5 Orbs", True, WHITE), (g.damage_btn.x + 15, g.damage_btn.centery - 10))

            pygame.draw.rect(screen, (35, 35, 55), g.primary_wep_btn, border_radius=8)
            screen.blit(font.render(f"Primary Weapon: {g.primary_weapons[g.primary_idx]}", True, WHITE), (g.primary_wep_btn.x + 15, g.primary_wep_btn.centery - 10))

            pygame.draw.rect(screen, (35, 35, 55), g.secondary_wep_btn, border_radius=8)
            screen.blit(font.render(f"Secondary Weapon: {g.secondary_weapons[g.secondary_idx]}", True, WHITE), (g.secondary_wep_btn.x + 15, g.secondary_wep_btn.centery - 10))

            cur_sk = g.skins[g.selected_skin_idx]
            prev_x, prev_y = WIDTH // 2, 530
            pygame.draw.polygon(screen, cur_sk["color"] if cur_sk["unlocked"] else (100, 100, 100), [
                (prev_x, prev_y - 25),
                (prev_x - 20, prev_y + 20),
                (prev_x, prev_y + 10),
                (prev_x + 20, prev_y + 20)
            ])

            pygame.draw.rect(screen, (0, 200, 120), g.launch_btn_rect, border_radius=10)
            launch_txt = large_font.render("LAUNCH", True, WHITE)
            screen.blit(launch_txt, (g.launch_btn_rect.centerx - launch_txt.get_width()//2, g.launch_btn_rect.centery - launch_txt.get_height()//2))

        elif g.game_state == "SKINS":
            t_txt = large_font.render("SKINS VAULT (20)", True, WHITE)
            screen.blit(t_txt, (WIDTH // 2 - t_txt.get_width() // 2, 40))

            b_txt = font.render(f"Orbs: {g.total_banked_orbs}", True, COIN_COLOR)
            screen.blit(b_txt, (WIDTH // 2 - b_txt.get_width() // 2, 85))

            pygame.draw.rect(screen, (50, 50, 70), g.back_garage_btn, border_radius=6)
            screen.blit(font.render("< Garage", True, WHITE), (g.back_garage_btn.centerx - 30, g.back_garage_btn.centery - 10))

            cur_sk = g.skins[g.selected_skin_idx]
            prev_x, prev_y = WIDTH // 2, 280
            pygame.draw.polygon(screen, cur_sk["color"] if cur_sk["unlocked"] else (100, 100, 100), [
                (prev_x, prev_y - 40),
                (prev_x - 35, prev_y + 35),
                (prev_x, prev_y + 15),
                (prev_x + 35, prev_y + 35)
            ])

            s_name = large_font.render(cur_sk["name"], True, cur_sk["color"] if cur_sk["unlocked"] else WHITE)
            screen.blit(s_name, (WIDTH // 2 - s_name.get_width() // 2, 370))

            status_str = "UNLOCKED" if cur_sk["unlocked"] else f"COST: {cur_sk['cost']} ORBS"
            s_stat = font.render(status_str, True, COIN_COLOR if not cur_sk["unlocked"] else HEALTH_GREEN)
            screen.blit(s_stat, (WIDTH // 2 - s_stat.get_width() // 2, 420))

            pygame.draw.rect(screen, (40, 40, 60), g.skin_prev_btn, border_radius=8)
            pygame.draw.rect(screen, (40, 40, 60), g.skin_next_btn, border_radius=8)
            screen.blit(large_font.render("<", True, WHITE), (g.skin_prev_btn.centerx - 8, g.skin_prev_btn.centery - 15))
            screen.blit(large_font.render(">", True, WHITE), (g.skin_next_btn.centerx - 8, g.skin_next_btn.centery - 15))

            if not cur_sk["unlocked"]:
                pygame.draw.rect(screen, (200, 140, 0), g.skin_buy_btn, border_radius=8)
                buy_txt = large_font.render("BUY SKIN", True, WHITE)
                screen.blit(buy_txt, (g.skin_buy_btn.centerx - buy_txt.get_width()//2, g.skin_buy_btn.centery - buy_txt.get_height()//2))

        elif g.game_state == "PLAYING":
            for l in g.lasers: pygame.draw.rect(screen, l[4], (int(l[0]), int(l[1]), 5, 16), border_radius=2)
            for m in g.missiles: pygame.draw.circle(screen, MISSILE_COLOR, (int(m[0]), int(m[1])), 4)
            for el in g.enemy_lasers: pygame.draw.rect(screen, ENEMY_LASER_COLOR, (int(el[0]), int(el[1]), 6, 14), border_radius=2)

            if g.shield_timer > 0 or g.dash_timer > 0:
                pygame.draw.circle(screen, SHIELD_COLOR, (int(g.player_x + g.player_w // 2), int(g.player_y + g.player_h // 2)), int(g.player_w * 0.8), 2)

            cur_skin_color = g.skins[g.selected_skin_idx]["color"]
            p_col = OVERCHARGE_COLOR if g.overcharge_timer > 0 else (TRIPLE_COLOR if g.triple_shot_timer > 0 else (RAPID_COLOR if g.rapid_fire_timer > 0 else cur_skin_color))

            px_int = int(g.player_x)
            py_int = int(g.player_y)
            pygame.draw.polygon(screen, p_col, [
                (px_int + g.player_w // 2, py_int),
                (px_int + 6, py_int + g.player_h - 6),
                (px_int + g.player_w // 2, py_int + g.player_h - 14),
                (px_int + g.player_w - 6, py_int + g.player_h - 6)
            ])
            pygame.draw.polygon(screen, WHITE, [
                (px_int + g.player_w // 2, py_int + 10),
                (px_int + g.player_w // 2 - 4, py_int + g.player_h - 18),
                (px_int + g.player_w // 2 + 4, py_int + g.player_h - 18)
            ])

            if g.boss:
                pygame.draw.rect(screen, BOSS_COLOR, (int(g.boss["x"]), int(g.boss["y"]), int(g.boss["w"]), int(g.boss["h"])), border_radius=6)
                pygame.draw.polygon(screen, (255, 100, 100), [
                    (int(g.boss["x"] + g.boss["w"] // 2), int(g.boss["y"] - 15)),
                    (int(g.boss["x"] + 10), int(g.boss["y"])),
                    (int(g.boss["x"] + g.boss["w"] - 10), int(g.boss["y"]))
                ])
                pygame.draw.rect(screen, HEALTH_GREEN, (int(g.boss["x"]), int(g.boss["y"] - 22), int(g.boss["w"] * (g.boss["hp"] / g.boss["max_hp"])), 6))

            for ast in g.asteroids:
                pygame.draw.circle(screen, ASTEROID_COLOR, (int(ast[0]), int(ast[1])), int(ast[2]))

            for e in g.enemies:
                ex, ey = int(e[0]), int(e[1])
                ew = int(e[2])
                pygame.draw.polygon(screen, e[5], [
                    (ex + ew//2, ey + ew if not e[7] else ey),
                    (ex, ey + (0 if e[7] else ew)),
                    (ex + ew, ey + (0 if e[7] else ew))
                ])

            for c in g.coins: pygame.draw.circle(screen, COIN_COLOR, (int(c[0]), int(c[1])), int(c[2]))
            for pu in g.powerups:
                pygame.draw.circle(screen, WHITE, (int(pu[0]), int(pu[1])), 12)

            fire_btn_col = HEALTH_RED if g.is_overheated else (0, 200, 255)
            pygame.draw.circle(screen, (30, 30, 45), (g.fire_btn_rect.centerx, g.fire_btn_rect.centery), g.fire_btn_rect.width // 2)
            pygame.draw.circle(screen, fire_btn_col, (g.fire_btn_rect.centerx, g.fire_btn_rect.centery), g.fire_btn_rect.width // 2 - 2, 2)
            f_txt = font.render("FIRE", True, fire_btn_col)
            screen.blit(f_txt, (g.fire_btn_rect.centerx - f_txt.get_width() // 2, g.fire_btn_rect.centery - f_txt.get_height() // 2))

            pygame.draw.circle(screen, (35, 35, 50), (g.bomb_btn_rect.centerx, g.bomb_btn_rect.centery), g.bomb_btn_rect.width // 2)
            pygame.draw.circle(screen, BOMB_COLOR, (g.bomb_btn_rect.centerx, g.bomb_btn_rect.centery), g.bomb_btn_rect.width // 2 - 2, 2)
            b_txt = font.render(f"NUKE:{g.bombs}", True, BOMB_COLOR)
            screen.blit(b_txt, (g.bomb_btn_rect.centerx - b_txt.get_width() // 2, g.bomb_btn_rect.centery - b_txt.get_height() // 2))

            pygame.draw.circle(screen, (35, 35, 50), (g.dash_btn_rect.centerx, g.dash_btn_rect.centery), g.dash_btn_rect.width // 2)
            pygame.draw.circle(screen, DASH_COLOR, (g.dash_btn_rect.centerx, g.dash_btn_rect.centery), g.dash_btn_rect.width // 2 - 2, 2)
            d_txt = font.render("DASH", True, DASH_COLOR)
            screen.blit(d_txt, (g.dash_btn_rect.centerx - d_txt.get_width() // 2, g.dash_btn_rect.centery - d_txt.get_height() // 2))

            screen.blit(font.render(f"Score: {g.score}", True, WHITE), (15, 15))
            screen.blit(font.render(f"Orbs: {g.coins_collected}", True, COIN_COLOR), (15, 38))

            for ft in g.floating_texts:
                screen.blit(font.render(ft[0], True, ft[4]), (int(ft[1]), int(ft[2])))

            pygame.draw.rect(screen, HEALTH_RED, (WIDTH - 140, 20, 120, 12), border_radius=3)
            pygame.draw.rect(screen, HEALTH_GREEN, (WIDTH - 140, 20, int(120 * (g.hp / g.max_hp)), 12), border_radius=3)

        elif g.game_state == "GAMEOVER":
            over_text = large_font.render("MISSION FAILED", True, ENEMY_COLOR)
            screen.blit(over_text, (WIDTH // 2 - over_text.get_width() // 2, HEIGHT // 3))

            score_final = font.render(f"Final Score: {g.score} | Orbs: {g.coins_collected}", True, WHITE)
            screen.blit(score_final, (WIDTH // 2 - score_final.get_width() // 2, HEIGHT // 3 + 55))

            pygame.draw.rect(screen, (0, 180, 120), g.restart_btn_rect, border_radius=8)
            r_txt = font.render("MAIN MENU", True, WHITE)
            screen.blit(r_txt, (g.restart_btn_rect.centerx - r_txt.get_width() // 2, g.restart_btn_rect.centery - r_txt.get_height() // 2))

        pygame.display.flip()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())